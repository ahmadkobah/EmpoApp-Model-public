package com.example.empoapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
