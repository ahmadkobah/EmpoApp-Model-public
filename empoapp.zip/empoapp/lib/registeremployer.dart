import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'loginorregisteremployer.dart';
import 'loginemployer.dart';
import 'homeemployer.dart';



class Registeremployer extends StatelessWidget {
  const Registeremployer({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAFAFD),
      body: Center(
        child: SingleChildScrollView(
          child: Container(
            width: 450,
            height: 834, // Increased height to accommodate new field
            clipBehavior: Clip.antiAlias,
            decoration: ShapeDecoration(
              color: const Color(0xFFFAFAFD),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(30),
              ),
            ),
            child: Stack(
              children: [
              // Back button
                Positioned(
                  left: 25,
                  top: 50,
                  child: GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const loginorregisteremployer(),
                        ),
                      );
                    },
                    child: const Icon(
                      Icons.arrow_back,
                      color: Color(0xFF0C0C26),
                      size: 32,
                    ),
                  ),
                ),

            Positioned(
              left: 24,
              top: 146,
              child: Text(
                'Registration',
                style: TextStyle(
                  color: const Color(0xFF0C0C26),
                  fontSize: 24,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w600,
                  height: 1.40,
                  letterSpacing: -0.36,
                ),
              ),
            ),

            Positioned(
              left: 24,
              top: 187,
              child: Opacity(
                opacity: 0.40,
                child: Text(
                    'Lets Register. lets find employees !',
                style: TextStyle(
                    color: const Color(0xFF0C0C26),
                fontSize: 14,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w400,
                height: 1.60,
                letterSpacing: -0.14,
              ),
            ),
          ),
        ),

        Positioned(
          left: -25,
          top: 105,
          child: SizedBox(
            width: 150,
            child: Text(
              'EmpÖ',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: const Color(0xFF356899),
                fontSize: 22,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w600,
                letterSpacing: -0.44,
              ),
            ),
          ),
        ),

        // Full Name
        Positioned(
          left: 5,
          top: 240,
          child: textFieldWithIcon('assets/fullname.png', 'Full Name'),
        ),

        // Email
        Positioned(
          left: 5,
          top: 320,
          child: textFieldWithIcon('assets/email.png', 'E-mail'),
        ),

        // Tax Number
        Positioned(
          left: 5,
          top: 400,
          child: textFieldWithIcon(
            'assets/tax.png', // Add your phone icon path here
            'TAX ID',
            keyboardType: TextInputType.phone,
          ),
        ),

        // Password
        Positioned(
          left: 5,
          top: 480,
          child: textFieldWithIcon(
              'assets/password.png',
              'Password',
              obscureText: true
          ),
        ),

        // Confirm Password
        Positioned(
          left: 5,
          top: 560,
          child: textFieldWithIcon(
            'assets/password.png',
            'Confirm Password',
            obscureText: true,
          ),
        ),

        // Register Button (moved down)
        Positioned(
          left: 5,
          top: 659.08, // Adjusted position
          child: GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const HomeEmployer()),
              );
            },
            child: Container(
              width: 400,
              height: 65.93,
              padding: const EdgeInsets.symmetric(
                  horizontal: 48, vertical: 16),
              decoration: ShapeDecoration(
                color: const Color(0xFF356899),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(5)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  Text(
                    'Register',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w500,
                      height: 1.50,
                      letterSpacing: -0.16,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),

        // Login prompt (moved down)
        Positioned(
          bottom: 50,
          left: 0,
          right: 0,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Text.rich(
              TextSpan(
                children: [
                  const TextSpan(
                    text: 'Already have an account? ',
                    style: TextStyle(
                      color: Color(0xFFBDBEC2),
                      fontSize: 14,
                      fontFamily: 'Circular Std',
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  TextSpan(
                    text: 'Log in',
                    style: const TextStyle(
                      color: Color(0xFF356899),
                      fontSize: 14,
                      fontFamily: 'Circular Std',
                      fontWeight: FontWeight.w400,
                    ),
                    recognizer: TapGestureRecognizer()
                      ..onTap = () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const loginemployer()),
                        );
                      },
                  ),
                ],
              ),
              textAlign: TextAlign.center,
            ),
          ),
        ),
        ],
      ),
    ),
    ),
    ),
    );
  }

  Widget textFieldWithIcon(
      String assetPath,
      String hintText, {
        bool obscureText = false,
        TextInputType keyboardType = TextInputType.text,
      }) {
    return Container(
      width: 400,
      height: 61.22,
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: ShapeDecoration(
        shape: RoundedRectangleBorder(
          side: const BorderSide(width: 1, color: Color(0xFFAFB0B5)),
          borderRadius: BorderRadius.circular(10),
        ),
      ),
      child: Row(
        children: [
          Image.asset(assetPath, width: 40, height: 40),
          const SizedBox(width: 10),
          Expanded(
            child: TextField(
              obscureText: obscureText,
              keyboardType: keyboardType,
              decoration: InputDecoration(
                border: InputBorder.none,
                hintText: hintText,
                hintStyle: const TextStyle(
                  color: Color(0xFFAFB0B5),
                  fontSize: 14,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w500,
                  height: 1.5,
                  letterSpacing: -0.14,
                ),
              ),
              style: const TextStyle(
                color: Colors.black,
                fontSize: 14,
                fontFamily: 'Poppins',
              ),
            ),
          ),
        ],
      ),
    );
  }
}