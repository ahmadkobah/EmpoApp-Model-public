import 'package:flutter/material.dart';
import 'homeemployer.dart';
import 'loginemployer.dart';
import 'switchingtoemployee.dart';

class SettingsEmployer extends StatefulWidget {
  const SettingsEmployer({super.key});

  @override
  State<SettingsEmployer> createState() => _SettingsEmployerState();
}

class _SettingsEmployerState extends State<SettingsEmployer> {
  bool isEmployerMode = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Settings',
          style: TextStyle(color: Colors.black),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const HomeEmployer()),
            );
          },
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16.0),
            child: CircleAvatar(
              radius: 18,
              backgroundImage: AssetImage('assets/googlelogo2.png'),
            ),
          ),
        ],
      ),
      backgroundColor: Colors.white,
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text(
            'Applications',
            style: TextStyle(
                fontWeight: FontWeight.bold, color: Colors.black54),
          ),
          const SizedBox(height: 10),
          _buildSettingsTile(Icons.person_outline, 'Profile Visibility'),
          _buildSettingsTile(Icons.notifications_none, 'Notification'),
          _buildSettingsTile(Icons.lock_outline, 'Change Password'),
          _buildSettingsTile(Icons.language, 'Language'),
          _buildSettingsTile(Icons.brightness_6_outlined, 'Theme'),
          _buildSettingsTile(Icons.logout, 'Logout', isDestructive: true, onTap: _showLogoutConfirmation),
          const SizedBox(height: 30),
          const Text(
            'About',
            style: TextStyle(
                fontWeight: FontWeight.bold, color: Colors.black54),
          ),
          const SizedBox(height: 10),
          _buildSettingsTile(Icons.privacy_tip_outlined, 'Privacy'),
          _buildSettingsTile(Icons.article_outlined, 'Terms and conditions'),
          _buildSettingsTile(Icons.help_outline, 'Help Center'),
          _buildSettingsTile(Icons.support_agent_outlined, 'Support'),
          _buildSettingsTile(Icons.info_outline, 'About'),
          const SizedBox(height: 30),
          _buildRoleSwitcher(),
        ],
      ),
    );
  }

  Widget _buildSettingsTile(IconData icon, String title,
      {bool isDestructive = false, VoidCallback? onTap}) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 0, vertical: 4),
      leading: Icon(icon, color: isDestructive ? Colors.red : Colors.black54),
      title: Text(
        title,
        style: TextStyle(
          color: isDestructive ? Colors.red : Colors.black,
          fontWeight: FontWeight.w500,
        ),
      ),
      trailing: const Icon(
          Icons.arrow_forward_ios, size: 16, color: Colors.black26),
      onTap: onTap,
    );
  }

  void _showLogoutConfirmation() {
    showDialog(
      context: context,
      builder: (context) =>
          AlertDialog(
            title: const Text('Logout'),
            content: const Text('Are you sure you want to logout?'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Cancel'),
              ),
              TextButton(
                onPressed: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const loginemployer()),
                  );
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Logged out successfully')),
                  );
                },
                child: const Text('Logout'),
              ),
            ],
          ),
    );
  }

  Widget _buildRoleSwitcher() {
    return Center(
      child: SizedBox(
        width: 250,
        height: 40,
        child: Stack(
          children: [
            // Background
            Container(
              alignment: Alignment.center,
              decoration: ShapeDecoration(
                color: const Color(0xFFF1F5FC),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
            ),
            // Animated Indicator
            AnimatedPositioned(
              duration: const Duration(milliseconds: 300),
              curve: Curves.easeInOut,
              left: isEmployerMode ? 4 : 126,
              // Tighter switch position
              top: 4,
              child: Container(
                width: 120,
                height: 32,
                decoration: ShapeDecoration(
                  color: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
              ),
            ),
            // Text Buttons
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                GestureDetector(
                  onTap: () {
                    setState(() {
                      isEmployerMode = true;
                    });
                  },
                  child: Container(
                    width: 120,
                    alignment: Alignment.center,
                    height: 40,
                    child: Text(
                      'Employer Mode',
                      style: TextStyle(
                        fontSize: 13, // Smaller text
                        color: isEmployerMode
                            ? const Color(0xFF0C0C26)
                            : const Color(0xFFBDBEC2),
                        fontWeight: FontWeight.w500,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    setState(() {
                      isEmployerMode = false;
                    });
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const SwitchingToEmployee()),
                    );
                  },
                  child: Container(
                    width: 120,
                    alignment: Alignment.center,
                    height: 40,
                    child: Text(
                      'Employee Mode',
                      style: TextStyle(
                        fontSize: 13,
                        color: !isEmployerMode
                            ? const Color(0xFF0C0C26)
                            : const Color(0xFFBDBEC2),
                        fontWeight: FontWeight.w500,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
