import 'package:flutter/material.dart';

import 'filteroption.dart';
import 'homescreen.dart';

class SearchResults extends StatelessWidget {
  const SearchResults({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: _buildAppBar(context),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSearchBar(context),
            const SizedBox(height: 20),
            _buildResultsCount(),
            const SizedBox(height: 20),
            _buildJobListing(
              position: 'UX Designer',
              company: 'Dribbble',
              rate: '40\$/h',
              location: 'Cairo, Egypt',
              status: 'Open',
              statusColor: const Color(0xFF0E9D57),
              statusBgColor: const Color(0xFFE8FDF2),
              imagePath: 'assets/dribble80.png',
            ),
            const SizedBox(height: 20),
            _buildJobListing(
              position: 'UX Designer',
              company: 'Facebook',
              rate: '55\$/h',
              location: 'Cairo, Egypt',
              status: 'Open',
              statusColor: const Color(0xFF0E9D57),
              statusBgColor: const Color(0xFFE8FDF2),
              imagePath: 'assets/facebook2.png',
            ),
            const SizedBox(height: 20),
            _buildJobListing(
              position: 'UX Designer',
              company: 'Spotify',
              rate: '46\$/h',
              location: 'Dubai, UAE',
              status: 'Closed',
              statusColor: const Color(0xFFB2215A),
              statusBgColor: const Color(0xFFFFEDED),
              imagePath: 'assets/spotify.png',
            ),
          ],
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar(context) {
    return AppBar(
      centerTitle: true,
      leading: IconButton(
        icon: const Icon(Icons.arrow_back, color: Color(0xFF0C0C26)),
        onPressed: () {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => HomeScreen()),
          );
        },
      ),
      title: const Text(
        'Search',
        style: TextStyle(
          color: Color(0xFF0C0C26),
          fontSize: 16,
          fontFamily: 'Poppins',
          fontWeight: FontWeight.w600,
          height: 1.30,
          letterSpacing: -0.16,
        ),
      ),
      backgroundColor: Colors.white,
      elevation: 0,
    );
  }

  Widget _buildSearchBar(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Container(
            height: 48,
            decoration: BoxDecoration(
              color: const Color(0xFFF1F1F2),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                width: 1,
                color: const Color(0xFF356899),
              ),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                const Icon(Icons.search, color: Color(0xFF94969D), size: 20),
                const SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    decoration: InputDecoration(
                      hintText: 'UX Design',
                      hintStyle: const TextStyle(
                        color: Colors.black,
                        fontSize: 15,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w400,
                        height: 1.50,
                        letterSpacing: -0.15,
                      ),
                      border: InputBorder.none,
                    ),
                    style: const TextStyle(
                      color: Color(0xFF0C0C26),
                      fontSize: 15,
                      fontFamily: 'Poppins',
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(width: 12),
        GestureDetector(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => FilterOption()),
            );
          },

          child: Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: const Color(0xFFF1F1F2),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                width: 1,
                color: const Color(0xFF356899),
              ),
            ),
            child: const Icon(Icons.filter_list, color: Color(0xFF3866E6)),
          ),
        ),
      ],
    );
  }


  Widget _buildResultsCount() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        const Text(
          'Results',
          style: TextStyle(
            color: Color(0xFF0C0C26),
            fontSize: 16,
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w600,
            height: 1.30,
            letterSpacing: -0.16,
          ),
        ),
        Text(
          '3 Jobs Found',
          style: TextStyle(
            color: const Color(0xFF356899),
            fontSize: 14,
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w500,
            height: 1.50,
            letterSpacing: -0.14,
          ),
        ),
      ],
    );
  }

  Widget _buildJobListing({
    required String position,
    required String company,
    required String rate,
    required String location,
    required String status,
    required Color statusColor,
    required Color statusBgColor,
    required String imagePath,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(
          width: 1,
          color: const Color(0xFF356899),
        ),
      ),
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  color: Colors.grey[200],
                  image: DecorationImage(
                    image: AssetImage(imagePath), // Use the imagePath parameter
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      position,
                      style: const TextStyle(
                        color: Color(0xFF0C0C26),
                        fontSize: 14,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w600,
                        height: 1.30,
                        letterSpacing: -0.14,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Opacity(
                      opacity: 0.5,
                      child: Text(
                        company,
                        style: const TextStyle(
                          color: Color(0xFF0C0C26),
                          fontSize: 12,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w400,
                          height: 1.60,
                          letterSpacing: -0.12,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    rate,
                    style: const TextStyle(
                      color: Color(0xFF0C0C26),
                      fontSize: 12,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w500,
                      height: 1.60,
                      letterSpacing: -0.12,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Opacity(
                    opacity: 0.5,
                    child: Text(
                      location,
                      style: const TextStyle(
                        color: Color(0xFF0C0C26),
                        fontSize: 13,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w400,
                        height: 1.60,
                        letterSpacing: -0.13,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                decoration: BoxDecoration(
                  color: statusBgColor,
                  borderRadius: BorderRadius.circular(50),
                ),
                child: Text(
                  status,
                  style: TextStyle(
                    color: statusColor,
                    fontSize: 13,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w500,
                    height: 1.60,
                    letterSpacing: -0.13,
                  ),
                ),
              ),
              const Text(
                'Full-Time',
                style: TextStyle(
                  color: Color(0xFF0C0C26),
                  fontSize: 12,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w500,
                  height: 1.60,
                  letterSpacing: -0.12,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}