import 'package:flutter/material.dart';
import 'loginorregister.dart';
import 'loginorregisteremployer.dart';

class SplitScreen extends StatefulWidget {
  const SplitScreen({super.key});

  @override
  State<SplitScreen> createState() => _SplitScreenState();
}

class _SplitScreenState extends State<SplitScreen> {
  String? selectedOption;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment(0.5, 0.0),
            end: Alignment(0.5, 1.0),
            colors: [Color(0xFF356899), Color(0xFF1A334B)],
          ),
          borderRadius: BorderRadius.circular(0),
        ),
        child: Stack(
          children: [
            Positioned(
              top: 120,
              left: MediaQuery.of(context).size.width / 2 - 75,
              child: SizedBox(
                width: 150,
                child: Image.asset(
                  'assets/logobig.png',
                  fit: BoxFit.contain,
                ),
              ),
            ),
            Positioned(
              top: 300,
              left: 40,
              right: 40,
              child: Column(
                children: [
                  GestureDetector(
                    onTap: () {
                      setState(() {
                        selectedOption = 'I am an Employer !';
                      });
                    },
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 18),
                      decoration: BoxDecoration(
                        color: selectedOption == 'I am an Employer !' ? const Color(0xFFFE6D73) : const Color(0xFFEB9498),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: const Text(
                        'I am an Employer !',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 16,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  GestureDetector(
                    onTap: () {
                      setState(() {
                        selectedOption = 'I am an Employee !';
                      });
                    },
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 18),
                      decoration: BoxDecoration(
                        color: selectedOption == 'I am an Employee !' ? const Color(0xFFDDBDA7) : const Color(0xFFDEC9BB),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: const Text(
                        'I am an Employee !',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 16,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Positioned(
              bottom: 100,
              left: MediaQuery.of(context).size.width / 2 - 85,
              child: GestureDetector(
                onTap: selectedOption == null
                    ? null
                    : () {
                  if (selectedOption == 'I am an Employer !') {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => loginorregisteremployer()),
                    );
                  } else if (selectedOption == 'I am an Employee !') {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => loginorregister()),
                    );
                  }
                },
                child: Container(
                  width: 170,
                  height: 50,
                  decoration: BoxDecoration(
                    color: selectedOption != null ? const Color(0xFF2C557D) : const Color(0xFF94969D),
                    borderRadius: BorderRadius.circular(30),
                  ),
                  alignment: Alignment.center,
                  child: const Text(
                    'Next',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w500,
                      letterSpacing: -0.16,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
