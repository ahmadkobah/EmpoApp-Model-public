import 'package:flutter/material.dart';
import 'messagesemployer.dart';
import 'savedemployer.dart';
import 'searchoptionemployer.dart';
import 'settingsemployer.dart.';
import 'notificationemployer.dart';
import 'newlisting.dart';
import 'yourlisting.dart';

class HomeEmployer extends StatefulWidget {
  const HomeEmployer({super.key});

  @override
  State<HomeEmployer> createState() => _HomeEmployerState();
}

class _HomeEmployerState extends State<HomeEmployer> {
  int _currentIndex = 0; // Tracks active tab


  final List<Widget> _pages = [
    HomeContent(), // Your current home content
    MessagesEmployer(),
    SavedEmployer(),
    NotificationEmployer(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAFAFD),
      body: _pages[_currentIndex], // Shows current page
      bottomNavigationBar: _buildBottomNavBar(),
    );
  }

  Widget _buildBottomNavBar() {
    return Container(
      height: 70,
      padding: const EdgeInsets.only(bottom: 10),
      child: Column(
        children: [
          const SizedBox(height: 4),
          Container(
            width: 305,
            height: 56,
            decoration: ShapeDecoration(
              image: DecorationImage(
                image: AssetImage("assets/googlewallpaper.png"),
                fit: BoxFit.cover,
                colorFilter: ColorFilter.mode(

                    Colors.white.withAlpha(127),
                    BlendMode.srcOver,
                ),
              ),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(45),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildNavIcon(Icons.home, 0),
                _buildNavIcon(Icons.message, 1),
                _buildPlusButton(), // The special "+" button
                _buildNavIcon(Icons.bookmark, 2),
                _buildNavIcon(Icons.notifications, 3),
              ],
            ),
          ),
        ],
      ),
    );
  }
  Widget _buildPlusButton() {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => NewListing()),
        );
      },
      child: Container(
        width: 44,
        height: 44,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: Colors.black, width: 2),
        ),
        child: const Icon(
          Icons.add,
          size: 28,
          color: Colors.black,
        ),
      ),
    );
  }

  Widget _buildNavIcon(IconData icon, int index) {
    bool isActive = _currentIndex == index;
    return GestureDetector(
      onTap: () => setState(() => _currentIndex = index),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            icon,
            size: 24,
            color: isActive ? const Color(0xFF3866E6) : Colors.black,
          ),
          const SizedBox(height: 2),
          if (isActive)
            Container(
              width: 4,
              height: 4,
              decoration: const BoxDecoration(
                color: Color(0xFF356899),
                shape: BoxShape.circle,
              ),
            ),
        ],
      ),
    );
  }
}

// Your original home content (extracted to separate widget)
class HomeContent extends StatelessWidget {
  const HomeContent({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          Container(
            height: 150,
            width: double.infinity,
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage("assets/googlewallpaper.png"),
                fit: BoxFit.cover,
                colorFilter: ColorFilter.mode(
                  Colors.white.withAlpha(127),
                  BlendMode.srcOver,
                ),
              ),
              borderRadius: const BorderRadius.only(
                bottomLeft: Radius.circular(28),
                bottomRight: Radius.circular(28),
              ),
            ),
            child: Stack(
              children: [
                // Top-left text
                Positioned(
                  top: 40,
                  left: 24,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Text(
                        'Hello !',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        'Google',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 22,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
                // Center logo
                const Center(
                  child: CircleAvatar(
                    radius: 32,
                    backgroundColor: Colors.white,
                    backgroundImage: AssetImage('assets/googlelogo48.png'),
                  ),
                ),
                // Settings button (top-right)
                Positioned(
                  top: 40,
                  right: 24,
                  child: IconButton(
                    icon: const Icon(Icons.settings, color: Colors.black),
                    onPressed: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => SettingsEmployer()));
                    },
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => SearchOptionEmployer()));
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Color(0xFF3866E6), width: 1),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.search, color: Color(0xFF3866E6)),
                          const SizedBox(width: 10),
                          const Text(
                            'Search a job or position',
                            style: TextStyle(
                              color: Colors.grey,
                              fontSize: 14,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Color(0xFF3866E6), width: 1),
                  ),
                  child: const Icon(Icons.filter_list, color: Color(0xFF3866E6)),
                )
              ],
            ),
          ),
          const SizedBox(height: 32),
          sectionHeader(context, "Your Listing"),
          const SizedBox(height: 16),
          yourListing(),
          const SizedBox(height: 32),
          sectionHeader(context, "Recommended Employers"),
          const SizedBox(height: 16),
          recommendedEmployers(),
          const SizedBox(height: 80),
        ],
      ),
    );
  }

  Widget sectionHeader(BuildContext context, String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: Color(0xFF0C0C26),
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),
          TextButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => YourListing()),
              );
            },
            style: TextButton.styleFrom(
              padding: EdgeInsets.zero,
              minimumSize: const Size(50, 30),
              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
            ),
            child: const Text(
              'See all',
              style: TextStyle(
                color: Color(0xFF94969D),
                fontSize: 13,
              ),
            ),
          ),
        ],
      ),
    );
  }


  Widget yourListing() {
    return SizedBox(
      height: 220,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 24),
        children: [
          jobCard(
            bgColor: const Color(0x7FEE7368),
            title: "Product Designer",
            company: "Google",
            tags: const ["Design", "Full-Time", "Junior"],
            price: "55\$ /H",
            location: "Cairo / Egypt",
            imagePath: "assets/googlelogo48.png",
          ),
          const SizedBox(width: 16),
          jobCard(
            bgColor: const Color(0x7FFBCC45),
            title: "Product Manager",
            company: "Google",
            tags: const ["Data", "Full-Time","Senior"],
            price: "45\$ /H",
            location: "Alexandria / Egypt",
            imagePath: "assets/googlelogo48.png",
          ),
        ],
      ),
    );
  }

  Widget jobCard({
    required Color bgColor,
    required String title,
    required String company,
    required List<String> tags,
    required String price,
    required String location,
    required String imagePath,
  }) {
    return Container(
      width: 280,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(24),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: const BoxDecoration(
              color: Colors.white,
              shape: BoxShape.circle,
            ),
            child: Center(
              child: SizedBox(
                width: 48,
                height: 48,
                child: Image.asset(
                  imagePath,
                  fit: BoxFit.contain,
                  errorBuilder: (context, error, stackTrace) =>
                  const Icon(Icons.business, size: 48),
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            title,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            company,
            style: TextStyle(
              color: Colors.white.withAlpha(191),
              fontSize: 14,
            ),
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 8,
            children: tags
                .map(
                  (tag) => Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.white.withAlpha(38),
                  borderRadius: BorderRadius.circular(65),
                ),
                child: Text(
                  tag,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 11,
                  ),
                ),
              ),
            )
                .toList(),
          ),
          const Spacer(),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                price,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                ),
              ),
              Text(
                location,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget recommendedEmployers() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Row(
        children: [
          recommendedCard(
            bgColor: const Color(0xFFDDF5DC),
            name: "Sofian Shbili",
            title: "Product Designer",
            location: "Cairo, Egypt",
            imagePath: "assets/profile5.png",
          ),
          const SizedBox(width: 16),
          recommendedCard(
            bgColor: const Color(0xFFEAF1FF),
            name: "Ahmed Skrill",
            title: "Sr Dev",
            location: "Alexandria, Egypt",
            imagePath: "assets/profile2.png",
          ),
        ],
      ),
    );
  }

  Widget recommendedCard({
    required Color bgColor,
    required String name,
    required String title,
    required String location,
    required String imagePath,
  }) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 24),
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: BorderRadius.circular(24),
        ),
        child: Column(
          children: [
            Image.asset(
              imagePath,
              width: 36,
              height: 36,
              errorBuilder: (context, error, stackTrace) => const Icon(Icons.error),
            ),
            const SizedBox(height: 12),
            Text(
              name,
              style: const TextStyle(
                fontWeight: FontWeight.w600,
                color: Color(0xFF0C0C26),
              ),
            ),
            const SizedBox(height: 4),
            Text(
              title,
              style: const TextStyle(color: Color(0xFF7A7C84)),
            ),
            const SizedBox(height: 8),
            Text(
              location,
              style: const TextStyle(
                fontWeight: FontWeight.w500,
                color: Color(0xFF0C0C26),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Simple placeholder for other tabs
class PlaceholderScreen extends StatelessWidget {
  final String title;

  const PlaceholderScreen({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        title,
        style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
      ),
    );
  }
}



























