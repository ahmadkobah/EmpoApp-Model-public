import 'package:flutter/material.dart';
import 'employeereview.dart';
import 'homeemployer.dart';
import 'messagesemployer.dart';
import 'savedemployer.dart';
import 'notificationemployer.dart';
import 'newlisting.dart';

class Applications extends StatelessWidget {
  final String companyName;
  final String jobTitle;

  const Applications({
    super.key,
    required this.companyName,
    required this.jobTitle,
  });

  @override
  Widget build(BuildContext context) {
    List<Map<String, dynamic>> applicants = [
      {
        "name": "Sofian Shbili",
        "role": "Product Designer",
        "type": "Training",
        "status": "On Review",
        "statusColor": Color(0xFFE8F7FD),
        "textColor": Color(0xFF0E4B9D),
        "imageAsset": "assets/profile5.png"
      },
      {
        "name": "Ahmad Skrill",
        "role": "UX Designer",
        "type": "Full-Time",
        "status": "Open",
        "statusColor": Color(0xFFE8FDF2),
        "textColor": Color(0xFF0E9D57),
        "imageAsset": "assets/profile2.png"
      },
      {
        "name": "Abdallah Jerry",
        "role": "Sr Developer",
        "type": "Part-Time",
        "status": "Closed",
        "statusColor": Color(0xFFFFEDED),
        "textColor": Color(0xFFB2215A),
        "imageAsset": "assets/profile6.png"
      },
    ];

    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          _buildHeader(context),
          const SizedBox(height: 16),
          Expanded(
            child: SingleChildScrollView(
              child: Center(
                child: Container(
                  width: 450,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(30),
                  ),
                  child: Column(
                    children: [
                      const SizedBox(height: 20),
                      const Text(
                        'Application List',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'Poppins',
                          color: Color(0xFF0C0C26),
                          letterSpacing: -0.16,
                        ),
                      ),
                      const SizedBox(height: 20),
                      Container(
                        width: 400,
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          border: Border.all(color: const Color(0xFF356899), width: 1),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Column 1: Logo
                            Image.asset(
                              'assets/googlelogo2.png',
                              height: 40,
                              width: 40,
                            ),
                            const SizedBox(width: 12),

                            // Column 2: Job Title + Company Name
                            Expanded(
                              flex: 2,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    jobTitle,
                                    style: const TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w600,
                                      fontFamily: 'Poppins',
                                      color: Color(0xFF0C0C26),
                                      letterSpacing: -0.14,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Opacity(
                                    opacity: 0.5,
                                    child: Text(
                                      companyName,
                                      style: const TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.w400,
                                        fontFamily: 'Poppins',
                                        color: Color(0xFF0C0C26),
                                        letterSpacing: -0.12,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),

                            // Column 3: Salary + Location
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: const [
                                Text(
                                  '55\$/h',
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w500,
                                    fontFamily: 'Poppins',
                                    color: Color(0xFF0C0C26),
                                    letterSpacing: -0.12,
                                  ),
                                ),
                                SizedBox(height: 4),
                                Opacity(
                                  opacity: 0.5,
                                  child: Text(
                                    'Cairo, Egypt',
                                    style: TextStyle(
                                      fontSize: 13,
                                      fontWeight: FontWeight.w400,
                                      fontFamily: 'Poppins',
                                      color: Color(0xFF0C0C26),
                                      letterSpacing: -0.13,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 20),
                      ...applicants.map((applicant) => Padding(
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        child: GestureDetector(
                          onTap: () {
                            if (applicant["name"] == "Sofian Shbili") {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => EmployeeReview(),
                                ),
                              );
                            }
                          },
                          child: Container(
                            width: 400,
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              border: Border.all(color: const Color(0xFF356899), width: 1),
                              borderRadius: BorderRadius.circular(15),
                              color: Colors.white,
                            ),
                            child: Row(
                              children: [
                                CircleAvatar(
                                  radius: 24,
                                  backgroundImage: AssetImage(applicant["imageAsset"]),
                                ),
                                const SizedBox(width: 16),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        applicant["name"],
                                        style: const TextStyle(
                                          fontSize: 14,
                                          fontWeight: FontWeight.w600,
                                          fontFamily: 'Poppins',
                                          color: Color(0xFF0C0C26),
                                          letterSpacing: -0.14,
                                        ),
                                      ),
                                      Opacity(
                                        opacity: 0.5,
                                        child: Text(
                                          applicant["role"],
                                          style: const TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w600,
                                            fontFamily: 'Poppins',
                                            color: Color(0xFF0C0C26),
                                            letterSpacing: -0.14,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    Text(
                                      applicant["type"],
                                      style: const TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.w500,
                                        fontFamily: 'Poppins',
                                        color: Color(0xFF0C0C26),
                                        letterSpacing: -0.12,
                                      ),
                                    ),
                                    const SizedBox(height: 8),
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                      decoration: BoxDecoration(
                                        color: applicant["statusColor"],
                                        borderRadius: BorderRadius.circular(50),
                                      ),
                                      child: Text(
                                        applicant["status"],
                                        style: TextStyle(
                                          fontSize: 13,
                                          fontWeight: FontWeight.w500,
                                          fontFamily: 'Poppins',
                                          color: applicant["textColor"],
                                          letterSpacing: -0.13,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      )),
                      const SizedBox(height: 40),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: _buildBottomNavBar(context),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Container(
      height: 160,
      decoration: BoxDecoration(
        image: DecorationImage(
          image: AssetImage("assets/googlewallpaper.png"),
          fit: BoxFit.cover,
          colorFilter: ColorFilter.mode(
            Colors.white.withAlpha(127),
            BlendMode.srcOver,
          ),
        ),
        borderRadius: const BorderRadius.only(
          bottomLeft: Radius.circular(28),
          bottomRight: Radius.circular(28),
        ),
      ),
      child: Stack(
        children: [
          Positioned(
            top: 65,
            left: 24,
            child: const Text(
              "Google",
              style: TextStyle(
                color: Colors.black,
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Center(
            child: CircleAvatar(
              radius: 32,
              backgroundColor: Colors.white,
              backgroundImage: AssetImage('assets/googlelogo48.png'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomNavBar(BuildContext context) {
    return Container(
      height: 70,
      padding: const EdgeInsets.only(bottom: 10),
      child: Column(
        children: [
          const SizedBox(height: 4),
          Container(
            width: 305,
            height: 56,
            decoration: ShapeDecoration(
              image: DecorationImage(
                image: AssetImage("assets/googlewallpaper.png"),
                fit: BoxFit.cover,
                colorFilter: ColorFilter.mode(
                  Colors.white.withAlpha(127),
                  BlendMode.srcOver,
                ),
              ),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(45),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildNavIcon(context, Icons.home, 0),
                _buildNavIcon(context, Icons.message, 1),
                _buildPlusButton(context),
                _buildNavIcon(context, Icons.bookmark, 2),
                _buildNavIcon(context, Icons.notifications, 3),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNavIcon(BuildContext context, IconData icon, int index) {
    return GestureDetector(
      onTap: () {
        switch (index) {
          case 0:
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => HomeEmployer()),
            );
            break;
          case 1:
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => MessagesEmployer()),
            );
            break;
          case 2:
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => SavedEmployer()),
            );
            break;
          case 3:
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => NotificationEmployer()),
            );
            break;
        }
      },
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            icon,
            size: 24,
            color: Colors.black,
          ),
        ],
      ),
    );
  }

  Widget _buildPlusButton(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => NewListing()),
        );
      },
      child: Container(
        width: 44,
        height: 44,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: Colors.black, width: 2),
        ),
        child: const Icon(
          Icons.add,
          size: 28,
          color: Colors.black,
        ),
      ),
    );
  }
}

