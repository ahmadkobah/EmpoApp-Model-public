import 'package:flutter/material.dart';
import 'setb.dart';
import 'splitscreen.dart';

class SetA extends StatelessWidget {
  const SetA({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        clipBehavior: Clip.antiAlias,
        decoration: const ShapeDecoration(
          color: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(30),
              topRight: Radius.circular(30),
            ),
          ),
        ),
        child: Stack(
          children: [
            Positioned(
              left: -20,
              top: -275,
              child: Opacity(
                opacity: 0.20,
                child: Container(
                  width: 450,
                  height: 450,
                  decoration: const ShapeDecoration(
                    color: Color(0xFF224261),
                    shape: OvalBorder(),
                  ),
                ),
              ),
            ),
            Positioned(
              left: 32,
              top: 535,
              child: SizedBox(
                width: 346,
                child: Text(
                  'Search your job',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: const Color(0xFF0C0C26),
                    fontSize: 28,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w600,
                    letterSpacing: -0.42,
                  ),
                ),
              ),
            ),
            Positioned(
              left: 49,
              top: 600,
              child: SizedBox(
                width: 312,
                child: Text(
                  'Figure out your top five priorities whether it is company culture, salary.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: const Color(0xFF94969D),
                    fontSize: 15,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w400,
                    height: 1.50,
                    letterSpacing: -0.15,
                  ),
                ),
              ),
            ),
            Positioned(
              left: 94,
              top: 270,
              child: Container(
                width: 240,
                height: 260,
                decoration: const BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage('assets/img.png'), // Replace with your image
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            // Progress indicators
            Positioned(
              left: 161,
              top: 700,
              child: Container(
                width: 36.84,
                height: 10,
                decoration: ShapeDecoration(
                  color: const Color(0xFF2B557C),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(26),
                  ),
                ),
              ),
            ),
            Positioned(
              left: 208.37,
              top: 700,
              child: Container(
                width: 10.53,
                height: 10,
                decoration: ShapeDecoration(
                  color: const Color(0xFFE4E4E6),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(26),
                  ),
                ),
              ),
            ),
            Positioned(
              left: 229.42,
              top: 700,
              child: Container(
                width: 10.53,
                height: 10,
                decoration: ShapeDecoration(
                  color: const Color(0xFFE4E4E6),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(26),
                  ),
                ),
              ),
            ),
            Positioned(
              left: 250.47,
              top: 700,
              child: Container(
                width: 10.53,
                height: 10,
                decoration: ShapeDecoration(
                  color: const Color(0xFFE4E4E6),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(26),
                  ),
                ),
              ),
            ),
            // App logo
            Positioned(
              left: 130,
              top: 100,
              child: SizedBox(
                width: 150,
                child: Text(
                  'EmpÖ',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: const Color(0xFF356899),
                    fontSize: 32,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w600,
                    letterSpacing: -0.64,
                  ),
                ),
              ),
            ),

            // Skip button
            Positioned(
              left: 90,
              top: 750,
              child: GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const SplitScreen()),
                  );
                },
                child: SizedBox(
                  width: 37,
                  height: 28,
                  child: Text(
                    'Skip',
                    style: TextStyle(
                      color: const Color(0xFF94969D),
                      fontSize: 16,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w500,
                      height: 1.50,
                      letterSpacing: -0.16,
                    ),
                  ),
                ),
              ),
            ),

            // Next button
            Positioned(
              left: 200,
              top: 740,
              child: GestureDetector(
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const SetB()),
                  );
                },
                child: Container(
                  width: 171,
                  height: 50,
                  padding: const EdgeInsets.symmetric(horizontal: 48, vertical: 16),
                  decoration: ShapeDecoration(
                    color: const Color(0xFF2C557D),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                  ),
                  child: Center(
                    child: Text(
                      'Next',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w500,
                        height: 1.50,
                        letterSpacing: -0.16,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
