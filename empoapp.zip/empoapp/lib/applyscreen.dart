import 'package:flutter/material.dart';

import 'confirmationscreen.dart';

class ApplyScreen extends StatefulWidget {
  final String jobTitle;
  final String company;
  final String location;
  final String salary;
  final dynamic companyLogo;


  const ApplyScreen({
    super.key,
    required this.jobTitle,
    required this.company,
    required this.location,
    required this.salary,
    required this.companyLogo,
  });

  @override
  State<ApplyScreen> createState() => _ApplyScreenState();
}

class _ApplyScreenState extends State<ApplyScreen> {
  late TextEditingController _coverLetterController;
  String? _selectedResume;
  int _selectedProfileIndex = 0;

  @override
  void initState() {
    super.initState();
    _coverLetterController = TextEditingController();
  }

  @override
  void dispose() {
    _coverLetterController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF2C5F8A),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: BackButton(color: Colors.white),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Job Info Box
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  widget.companyLogo,
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(widget.jobTitle, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                        Text(widget.company),
                      ],
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(widget.salary, style: const TextStyle(fontWeight: FontWeight.bold)),
                      Text(widget.location),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // Profile Section
            _sectionTitle('Select a profile'),
            Row(
              children: [
                _profileCard(0, 'assets/profile5.png', 'Sofian Shbili', 'UI/UX Designer'),
                _addProfileCard(),
              ],
            ),

            const SizedBox(height: 24),

            // Resume Section
            _sectionTitle('Select a resume'),
            Row(
              children: [
                _resumeCard('UX Designer', 'Sofian Shbili', 'resume1'),
                const SizedBox(width: 12),
                _resumeCard('Add Resume', '', null),
              ],
            ),

            const SizedBox(height: 24),

            // Cover Letter
            _sectionTitle('Cover Later (Optional)'),
            TextField(
              controller: _coverLetterController,
              maxLines: 5,
              decoration: InputDecoration(
                hintText: 'Write or Upload a cover letter .....',
                filled: true,
                fillColor: Colors.white,
                suffixIcon: IconButton(
                  icon: const Icon(Icons.upload_file),
                  onPressed: () {
                    // Upload file action
                  },
                ),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),

            const SizedBox(height: 32),

            // Apply Button
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ConfirmationScreen(
                        jobTitle: widget.jobTitle,
                        company: widget.company,
                        location: widget.location,
                        salary: widget.salary,
                        companyLogo: widget.companyLogo,
                      ),
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  backgroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                child: const Text(
                  'Apply Now !',
                  style: TextStyle(
                    color: Color(0xFF2C5F8A),
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),

            ),
          ],
        ),
      ),
    );
  }

  Widget _sectionTitle(String title) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Text(title, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600)),
    );
  }

  Widget _profileCard(int index, String imagePath, String name, String role) {
    final isSelected = _selectedProfileIndex == index;
    return GestureDetector(
      onTap: () => setState(() => _selectedProfileIndex = index),
      child: Container(
        width: 120,
        margin: const EdgeInsets.only(right: 12, top: 12),
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: isSelected ? Colors.white : Colors.white24,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: isSelected ? Colors.white : Colors.transparent, width: 2),
        ),
        child: Column(
          children: [
            CircleAvatar(backgroundImage: AssetImage(imagePath), radius: 30),
            const SizedBox(height: 8),
            Text(name, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
            Text(role, style: const TextStyle(fontSize: 12), textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }

  Widget _addProfileCard() {
    return GestureDetector(
      onTap: () {
        // Add profile logic
      },
      child: Container(
        width: 120,
        margin: const EdgeInsets.only(top: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white24,
          borderRadius: BorderRadius.circular(12),
        ),
        child: const Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.add, size: 32, color: Colors.white),
            SizedBox(height: 8),
            Text('Add Profile', style: TextStyle(color: Colors.white, fontSize: 12), textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }

  Widget _resumeCard(String title, String subtitle, String? value) {
    final isSelected = _selectedResume == value;
    return GestureDetector(
      onTap: () => setState(() => _selectedResume = value),
      child: Container(
        width: 140,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: isSelected ? Colors.white : Colors.white24,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: isSelected ? Colors.white : Colors.transparent, width: 2),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
            if (subtitle.isNotEmpty) Text(subtitle, style: const TextStyle(fontSize: 12)),
          ],
        ),
      ),
    );
  }
}
