import 'package:flutter/material.dart';

import 'googlejob.dart';
import 'homescreen.dart';

class JobResults extends StatelessWidget {
  const JobResults({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Column(
          children: [
            _buildHeader(context),
            _buildCompanyProfile(),
            _buildSectionHeader(
              title: 'Featured Jobs',
              onSeeAll: () {}, // Add your see all functionality
            ),
            _buildFeaturedJobs(),
            _buildSectionHeader(
              title: 'Recommended Jobs',
              onSeeAll: () {}, // Add your see all functionality
            ),
            _buildJobListings(context), //context
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 35, bottom: 1),
      child: Stack(
        children: [
          // Back arrow button
          Align(
            alignment: Alignment.centerLeft,
            child: IconButton(
              icon: const Icon(Icons.arrow_back, color: Color(0xFF0C0C26)),
              onPressed: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => HomeScreen()),
                );
              },
            ),
          ),
          // Centered title
          const Center(
            child: Text(
              'Google Jobs',
              style: TextStyle(
                color: Color(0xFF0C0C26),
                fontSize: 16,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w600,
                height: 1.30,
                letterSpacing: -0.16,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCompanyProfile() {
    return Container(
      width : 400,
      height: 200,
      margin: const EdgeInsets.symmetric(horizontal: 25, vertical: 0),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(30),
        border: Border.all(
          width: 1,
          color: const Color(0xFF356899),
        ),
      ),
      child: Column(
        children: [
          // Company logo
          Container(
            width: 75,
            height: 75,
            decoration: const ShapeDecoration(
              color: Colors.white,
              shape: OvalBorder(
                side: BorderSide(
                  width: 1,
                  color: Color(0xFF356899),
                ),
              ),
            ),
            child: ClipOval(
              child: Image.asset(
                'assets/googlelogo48.png', // Path to your logo image
                fit: BoxFit.cover, // Ensures the image fits within the container
              ),
            ),
          ),
          const SizedBox(height: 10),
          // Company name
          const Text(
            'Google',
            style: TextStyle(
              color: Colors.black,
              fontSize: 16,
              fontFamily: 'Poppins',
              fontWeight: FontWeight.w600,
              height: 1.30,
              letterSpacing: -0.16,
            ),
          ),
          const SizedBox(height: 1),
          // Stats row
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildStatItem('Open', '140'),
              _buildStatItem('Hired', '176K'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatItem(String label, String value) {
    return Column(
      children: [
        Text(
          label,
          style: const TextStyle(
            color: Color(0xFF94969D),
            fontSize: 13,
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w400,
            height: 1.60,
            letterSpacing: -0.13,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: const TextStyle(
            color: Color(0xFF0C0C26),
            fontSize: 15,
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w600,
            height: 1.30,
            letterSpacing: -0.15,
          ),
        ),
      ],
    );
  }

  Widget _buildSectionHeader({required String title, required VoidCallback onSeeAll}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: Color(0xFF0C0C26),
              fontSize: 16,
              fontFamily: 'Poppins',
              fontWeight: FontWeight.w600,
              height: 1.30,
              letterSpacing: -0.16,
            ),
          ),
          GestureDetector(
            onTap: onSeeAll,
            child: const Text(
              'See all',
              style: TextStyle(
                color: Color(0xFF94969D),
                fontSize: 13,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w400,
                height: 1.60,
                letterSpacing: -0.13,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFeaturedJobs() {
    return SizedBox(
      height: 220,
      child: Stack(
        children: [
          // Background circles
          Positioned(
            left: 25,
            top: 100,
            child: Container(
              width: 100,
              height: 100,
              decoration: const ShapeDecoration(
                color: Color(0x7FFBBC04),
                shape: OvalBorder(),
              ),
            ),
          ),
          Positioned(
            right: 25,
            top: 100,
            child: Container(
              width: 100,
              height: 100,
              decoration: const ShapeDecoration(
                color: Color(0x7FEA4335),
                shape: OvalBorder(),
              ),
            ),
          ),
          Positioned(
            left: 25,
            bottom: 0,
            child: Container(
              width: 100,
              height: 100,
              decoration: const ShapeDecoration(
                color: Color(0x7F34A853),
                shape: OvalBorder(),
              ),
            ),
          ),
          Positioned(
            right: 25,
            bottom: 0,
            child: Container(
              width: 100,
              height: 100,
              decoration: const ShapeDecoration(
                color: Color(0x7F4285F4),
                shape: OvalBorder(),
              ),
            ),
          ),
          // Job cards
          Center(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _buildJobCard(
                  position: 'Sr Developer',
                  company: 'Google',
                  rate: '50\$/h',
                  color: const Color(0x7FFBBC04),
                ),
                const SizedBox(width: 20),
                _buildJobCard(
                  position: 'Jr Executive',
                  company: 'Google',
                  rate: '48\$/h',
                  color: const Color(0x7FEA4335),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildJobCard({
    required String position,
    required String company,
    required String rate,
    required Color color,
  }) {
    return Container(
      width: 190,
      height: 190,
      decoration: ShapeDecoration(
        color: Colors.white,
        shape: RoundedRectangleBorder(
          side: const BorderSide(
            width: 1,
            color: Color(0xFF356899),
          ),
          borderRadius: BorderRadius.circular(10),
        ),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // Logo
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color.withAlpha(38),
            ),
            child: ClipOval(
              child: Image.asset(
                'assets/logogoogle20.png', // Path to your logo image
                fit: BoxFit.cover, // Ensures the image fits within the container
              ),
            ),
          ),
          const SizedBox(height: 12),
          // Position
          Text(
            position,
            style: const TextStyle(
              color: Color(0xFF0C0C26),
              fontSize: 14,
              fontFamily: 'Poppins',
              fontWeight: FontWeight.w600,
              height: 1.30,
              letterSpacing: -0.14,
            ),
          ),
          const SizedBox(height: 8),
          // Company
          Opacity(
            opacity: 0.5,
            child: Text(
              company,
              style: const TextStyle(
                color: Color(0xFF0C0C26),
                fontSize: 12,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w400,
                height: 1.60,
                letterSpacing: -0.12,
              ),
            ),
          ),
          const SizedBox(height: 20),
          // Rate
          Text(
            rate,
            style: const TextStyle(
              color: Color(0xFF0C0C26),
              fontSize: 12,
              fontFamily: 'Poppins',
              fontWeight: FontWeight.w500,
              height: 1.60,
              letterSpacing: -0.12,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildJobListings(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 25),
      child: Column(
        children: [
          _buildJobListingItem(
            position: 'Product Manager',
            company: 'Google',
            location: 'Cairo, Egypt',
            rate: '55\$/h',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => GoogleJob()),
              );
            },
          ),
          const SizedBox(height: 20),
          _buildJobListingItem(
            position: 'UX Designer',
            company: 'Google',
            location: 'Dubai, UAE',
            rate: '45\$/h',
          ),
        ],
      ),
    );
  }

  Widget _buildJobListingItem({
    required String position,
    required String company,
    required String location,
    required String rate,
    VoidCallback? onTap,
  }) {
    return GestureDetector(
        onTap: onTap,  // Ensure this calls the function if provided
        child: Container(
      height: 100,
      decoration: ShapeDecoration(
        color: Colors.white,
        shape: RoundedRectangleBorder(
          side: const BorderSide(
            width: 1,
            color: Color(0xFF356899),
          ),
          borderRadius: BorderRadius.circular(10),
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            // Logo
            Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color(0xFFF1F1F2), // Background color for the logo
              ),
              child: ClipOval(
                child: Image.asset(
                  'assets/logogoogle20.png', // Path to your logo image
                  fit: BoxFit.cover, // Ensures the image fits within the container
                ),
              ),
            ),
            const SizedBox(width: 16),
            // Job info
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    position,
                    style: const TextStyle(
                      color: Color(0xFF0C0C26),
                      fontSize: 14,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w600,
                      height: 1.30,
                      letterSpacing: -0.14,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Opacity(
                    opacity: 0.5,
                    child: Text(
                      company,
                      style: const TextStyle(
                        color: Color(0xFF0C0C26),
                        fontSize: 12,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w400,
                        height: 1.60,
                        letterSpacing: -0.12,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            // Location and rate
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  rate,
                  style: const TextStyle(
                    color: Color(0xFF0C0C26),
                    fontSize: 12,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w500,
                    height: 1.60,
                    letterSpacing: -0.12,
                  ),
                ),
                const SizedBox(height: 4),
                Opacity(
                  opacity: 0.5,
                  child: Text(
                    location,
                    style: const TextStyle(
                      color: Color(0xFF0C0C26),
                      fontSize: 13,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w400,
                      height: 1.60,
                      letterSpacing: -0.13,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
      ),
    );
  }
}