import 'package:flutter/material.dart';
import 'homeemployer.dart';

class SavedEmployer extends StatelessWidget {
  const SavedEmployer({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAFAFD),
      appBar: AppBar(
        backgroundColor: const Color(0xFF3866E6),
        elevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            image: DecorationImage(
              image: AssetImage("assets/googlewallpaper.png"),
              fit: BoxFit.cover,
              colorFilter: ColorFilter.mode(
                Colors.white54, // ~50% white overlay
                BlendMode.srcOver,
              ),
            ),
          ),
        ),
        title: const Text(
          'Saved Employers',
          style: TextStyle(
            color: Color(0xFF0C0C26),
            fontSize: 20,
            fontWeight: FontWeight.w600,
          ),
        ),
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFF0C0C26)),
          onPressed: () {
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => const HomeEmployer()),
                  (Route<dynamic> route) => false,
            );
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: ListView(
          children: [
            const SizedBox(height: 24),
            _buildHeaderText(),
            const SizedBox(height: 24),
            _buildEmployerList(),
          ],
        ),
      ),
    );
  }

  Widget _buildHeaderText() {
    return RichText(
      text: const TextSpan(
        style: TextStyle(
          fontSize: 24,
          fontFamily: 'Poppins',
          fontWeight: FontWeight.w400,
          height: 1.4,
          color: Colors.black,
        ),
        children: [
          TextSpan(text: 'You '),
          TextSpan(text: 'saved'),
          TextSpan(text: ' 3 Employers'),
        ],
      ),
    );
  }

  Widget _buildEmployerList() {
    final List<Map<String, dynamic>> employers = [
      {
        'name': 'Sofian Shbili',
        'industry': 'Produckt Designer',
        'location': 'Cairo, Egypt',
        'status': 'Following',
        'statusColor': const Color(0xFF0E9D57),
        'bgColor': const Color(0xFFE8FDF2),
        'imagePath': "assets/profile5.png",
      },
      {
        'name': 'Ahmad Skrill',
        'industry': 'UI/UX Designer',
        'location': 'Alex, Egypt',
        'status': 'Following',
        'statusColor': const Color(0xFF0E9D57),
        'bgColor': const Color(0xFFE8FDF2),
        'imagePath': "assets/profile2.png",
      },
      {
        'name': 'Mohamed Esso',
        'industry': 'Sr Developer',
        'location': 'Cairo, Egypt',
        'status': 'Contacted',
        'statusColor': const Color(0xFF0E4B9D),
        'bgColor': const Color(0xFFE8F6FD),
        'imagePath': "assets/profile1.png",
      },
    ];

    return Column(
      children: employers.map((employer) => _buildEmployerCard(employer)).toList(),
    );
  }

  Widget _buildEmployerCard(Map<String, dynamic> employer) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(
          color: const Color(0xFF356899),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              image: DecorationImage(
                image: AssetImage(employer['imagePath']),
                fit: BoxFit.cover,
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  employer['name'],
                  style: const TextStyle(
                    color: Color(0xFF0C0C26),
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  employer['industry'],
                  style: const TextStyle(
                    color: Color(0xFF7A7C84),
                    fontSize: 12,
                  ),
                ),
                const SizedBox(height: 4),
                Opacity(
                  opacity: 0.5,
                  child: Text(
                    employer['location'],
                    style: const TextStyle(
                      color: Color(0xFF0C0C26),
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: employer['bgColor'],
              borderRadius: BorderRadius.circular(50),
            ),
            child: Text(
              employer['status'],
              style: TextStyle(
                color: employer['statusColor'],
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
