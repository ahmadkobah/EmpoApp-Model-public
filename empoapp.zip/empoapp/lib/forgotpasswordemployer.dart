import 'package:flutter/material.dart';
import 'loginorregisteremployer.dart';
import 'resetpasswordemployer.dart';



class ForgotPasswordEmployer extends StatefulWidget {
  const ForgotPasswordEmployer({super.key});

  @override
  State<ForgotPasswordEmployer> createState() => _ForgotPasswordEmployerState();
}

class _ForgotPasswordEmployerState extends State<ForgotPasswordEmployer> {
  bool isEmailSelected = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAFAFD),
      body: Center(
        child: SingleChildScrollView(
          child: Container(
            width: 450,
            height: 834,
            clipBehavior: Clip.antiAlias,
            decoration: ShapeDecoration(
              color: const Color(0xFFFAFAFD),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(30),
              ),
            ),
            child: Stack(
              children: [
                // Arrow Back
                Positioned(
                  left: 25,
                  top: 50,
                  child: GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const loginorregisteremployer(),
                        ),
                      );
                    },
                    child: const Icon(
                      Icons.arrow_back,
                      color: Color(0xFF0C0C26),
                      size: 32,
                    ),
                  ),
                ),

                // Logo
                Positioned(
                  top: 95,
                  left: 130,
                  child: SizedBox(
                    width: 150,
                    child: Text(
                      'EmpÖ',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: const Color(0xFF356899),
                        fontSize: 22,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w600,
                        letterSpacing: -0.44,
                      ),
                    ),
                  ),
                ),

                // Title
                const Positioned(
                  left: 120,
                  top: 165,
                  child: Text(
                    'Forgot Password',
                    style: TextStyle(
                      color: Color(0xFF0C0C26),
                      fontSize: 24,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w600,
                      height: 1.40,
                      letterSpacing: -0.36,
                    ),
                  ),
                ),

                // Subtitle
                const Positioned(
                  left: 80,
                  top: 215,
                  child: Opacity(
                    opacity: 0.40,
                    child: Text(
                      'Choose a method to reset your password.',
                      style: TextStyle(
                        color: Color(0xFF0C0C26),
                        fontSize: 14,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w400,
                        height: 1.60,
                        letterSpacing: -0.14,
                      ),
                    ),
                  ),
                ),

                // Switcher background
                Positioned(
                  left: 70,
                  top: 317,
                  child: Container(
                    width: 281,
                    height: 48,
                    decoration: ShapeDecoration(
                      color: const Color(0xFFF1F5FC),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                    ),
                  ),
                ),

                // Active tab
                AnimatedPositioned(
                  duration: const Duration(milliseconds: 300),
                  curve: Curves.easeInOut,
                  left: isEmailSelected ? 83 : 215,
                  top: 323,
                  child: Container(
                    width: 134.5,
                    height: 36,
                    decoration: ShapeDecoration(
                      color: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                    ),
                  ),
                ),

                // Email Tab
                Positioned(
                  left: 123,
                  top: 333,
                  child: GestureDetector(
                    onTap: () {
                      setState(() {
                        isEmailSelected = true;
                      });
                    },
                    child: Text(
                      'E-mail',
                      style: TextStyle(
                        color: isEmailSelected
                            ? const Color(0xFF0C0C26)
                            : const Color(0xFFBDBEC2),
                        fontSize: 13,
                        fontFamily: 'Circular Std',
                        fontWeight: FontWeight.w400,
                        letterSpacing: -0.07,
                      ),
                    ),
                  ),
                ),

                // Phone Tab
                Positioned(
                  left: 249,
                  top: 333,
                  child: GestureDetector(
                    onTap: () {
                      setState(() {
                        isEmailSelected = false;
                      });
                    },
                    child: Text(
                      'Mobile Number',
                      style: TextStyle(
                        color: !isEmailSelected
                            ? const Color(0xFF0C0C26)
                            : const Color(0xFFBDBEC2),
                        fontSize: 13,
                        fontFamily: 'Circular Std',
                        fontWeight: FontWeight.w400,
                        letterSpacing: -0.07,
                      ),
                    ),
                  ),
                ),

                // Conditional Input Fields
                Positioned(
                  left: 5,
                  top: 400,
                  child: isEmailSelected
                      ? const SizedBox(
                    width: 400,
                    child: TextField(
                      decoration: InputDecoration(
                        hintText: 'Enter your email',
                        border: OutlineInputBorder(
                          borderRadius:
                          BorderRadius.all(Radius.circular(10)),
                        ),
                        filled: true,
                        fillColor: Colors.white,
                      ),
                    ),
                  )
                      : Container(
                    width: 400,
                    height: 61,
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      border:
                      Border.all(color: const Color(0xFFBDBEC2)),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Row(
                      children: [
                        Image.asset(
                          'assets/egypt.png',
                          width: 24,
                          height: 24,
                        ),
                        const SizedBox(width: 8),
                        const Text(
                          '+20',
                          style: TextStyle(
                            fontSize: 16,
                            fontFamily: 'Poppins',
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        const VerticalDivider(
                          thickness: 1,
                          width: 20,
                          color: Color(0xFFBDBEC2),
                        ),
                        const Expanded(
                          child: TextField(
                            keyboardType: TextInputType.phone,
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              hintText: 'Enter Your Phone Number',
                              hintStyle: TextStyle(
                                color: Color(0xFFBDBEC2),
                                fontFamily: 'Poppins',
                                fontSize: 14,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                // Submit Button
                Positioned(
                  left: 5,
                  top: 500,
                  child: SizedBox(
                    width: 400,
                    height: 60,
                    child: ElevatedButton(
                      style: ButtonStyle(
                        backgroundColor: const WidgetStatePropertyAll(Color(0xFF356899)),
                        shape: const WidgetStatePropertyAll(
                          RoundedRectangleBorder(
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                          ),
                        ),
                      ),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const ResetPasswordEmployer(),
                          ),
                        );
                      },
                      child: const Text(
                        'Submit',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w500,
                          height: 1.5,
                          letterSpacing: -0.16,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
