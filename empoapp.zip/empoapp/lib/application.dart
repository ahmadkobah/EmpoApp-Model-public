import 'package:flutter/material.dart';
import 'googlejob.dart';
import 'facebookjob.dart';

class Application extends StatelessWidget {
  const Application({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAFAFD),
      appBar: AppBar(
        title: const Text(
          'Applications',
          style: TextStyle(
            color: Color(0xFF0C0C26),
            fontSize: 20,
            fontWeight: FontWeight.w600,
          ),
        ),
        centerTitle: true,
        elevation: 0,
        backgroundColor: const Color(0xFFFAFAFD),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFF0C0C26)),
          onPressed: () {
            // Back navigation
            Navigator.pop(context);
          },
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16.0),
            child: CircleAvatar(
              radius: 20,
              backgroundColor: Colors.transparent,
              backgroundImage: AssetImage('assets/profile5.png'),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 24),
            _buildHeaderText(),
            const SizedBox(height: 24),
            _buildCategoryFilters(),
            const SizedBox(height: 24),
            _buildJobList(context),  // Pass context to buildJobList
          ],
        ),
      ),
    );
  }

  Widget _buildHeaderText() {
    return RichText(
      text: const TextSpan(
        style: TextStyle(
          fontSize: 24,
          fontFamily: 'Poppins',
          fontWeight: FontWeight.w400,
          height: 1.4,
          color: Colors.black,
        ),
        children: [
          TextSpan(text: 'You have\n'),
          TextSpan(text: '4 job Applications'),
        ],
      ),
    );
  }

  Widget _buildCategoryFilters() {
    const List<String> categories = ['Received', 'Answered', 'Rejected'];
    int selectedIndex = 0;

    return SizedBox(
      height: 36,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: categories.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, index) {
          final isSelected = index == selectedIndex;
          return GestureDetector(
            onTap: () {
              // Add state logic if necessary
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
              decoration: BoxDecoration(
                color: isSelected ? const Color(0xFF356899) : Colors.transparent,
                borderRadius: BorderRadius.circular(97),
                border: Border.all(
                  color: isSelected ? Colors.transparent : const Color(0xFF94969D),
                  width: 1,
                ),
              ),
              child: Text(
                categories[index],
                style: TextStyle(
                  color: isSelected ? Colors.white : const Color(0xFF94969D),
                  fontSize: 14,
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildJobList(BuildContext context) {
    final List<Map<String, dynamic>> jobs = [
      {
        'company' : 'Spotify',
        'title': 'UI Designer',
        'rate': '72\$/h',
        'location': 'Cairo, Egypt',
        'imagePath': 'assets/spotify-logo-5434.png',
      },
      {
        'company' : 'Google',
        'title': 'Product Designer',
        'rate': '55\$/h',
        'location': 'Cairo, Egypt',
        'imagePath': 'assets/googlelogo2.png',
      },
      {
        'company' : 'Dribble',
        'title': 'UI Designer',
        'rate': '63\$/h',
        'location': 'Dubai, UAE',
        'imagePath': 'assets/dribble40.png',
      },
      {
        'company' : 'Facebook',
        'title': 'Product Designer',
        'rate': '55\$/h',
        'location': 'Cairo, Egypt',
        'imagePath': 'assets/facebooklogo.png',
      },
    ];

    return Column(
      children: jobs.map((job) => _buildJobCard(context, job)).toList(),
    );
  }

  Widget _buildJobCard(BuildContext context, Map<String, dynamic> job) {
    return GestureDetector(
      onTap: () {
        // Navigate based on company name
        if (job['company'] == 'Google') {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => GoogleJob()),
          );
        } else if (job['company'] == 'Facebook') {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => FacebookJob()),
          );
        }
      },
      child: Container(
        width: double.infinity,
        height: 120,
        margin: const EdgeInsets.only(bottom: 16),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(15),
          border: Border.all(
            color: const Color(0xFF356899),
            width: 1,
          ),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage(job['imagePath']),
                  fit: BoxFit.cover,
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    job['title'],
                    style: const TextStyle(
                      color: Color(0xFF0C0C26),
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Opacity(
                    opacity: 0.5,
                    child: Text(
                      job['rate'],
                      style: const TextStyle(
                        color: Color(0xFF0C0C26),
                        fontSize: 12,
                      ),
                    ),
                  ),
                  const Spacer(),
                  Container(
                    width: 140,
                    height: 35,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: const Color(0xFFE8FDF2),
                      borderRadius: BorderRadius.circular(50),
                    ),
                    child: Text(
                      job['location'],
                      style: const TextStyle(
                        color: Color(0xFF0E9D57),
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

}