import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'loginorregisteremployer.dart';
import 'registeremployer.dart';
import 'homeemployer.dart';
import 'forgotpasswordemployer.dart';


class loginemployer extends StatelessWidget {
  const loginemployer({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAFAFD),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Center(
            child: Container(
              width: 450,
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 20),

                  SizedBox(
                    height: 120,
                    child: Column(
                      children: [
                        const SizedBox(height: 50), // Top padding
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            // Back arrow
                            Padding(
                              padding: const EdgeInsets.only(left: 0),
                              child: GestureDetector(
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => const loginorregisteremployer(),
                                    ),
                                  );
                                },
                                child: const Icon(
                                  Icons.arrow_back,
                                  color: Color(0xFF0C0C26),
                                  size: 32,
                                ),
                              ),
                            ),

                            // Expanded spacer + centered EmpÖ
                            Expanded(
                              child: Center(
                                child: Text(
                                  'EmpÖ',
                                  style: const TextStyle(
                                    color: Color(0xFF356899),
                                    fontSize: 22,
                                    fontFamily: 'Poppins',
                                    fontWeight: FontWeight.w600,
                                    letterSpacing: -0.44,
                                  ),
                                ),
                              ),
                            ),

                            // Invisible spacer to balance arrow width on the right
                            const SizedBox(width: 32),
                          ],
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 40),

                  // Welcome Text
                  const Text(
                    'Welcome Back 👍',
                    style: TextStyle(
                      color: Color(0xFF0C0C26),
                      fontSize: 24,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w600,
                      height: 1.4,
                      letterSpacing: -0.36,
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Opacity(
                    opacity: 0.4,
                    child: Text(
                      'Let’s find employees together !',
                      style: TextStyle(
                        color: Color(0xFF0C0C26),
                        fontSize: 14,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w400,
                        height: 1.6,
                        letterSpacing: -0.14,
                      ),
                    ),
                  ),
                  const SizedBox(height: 40),

                  // Updated Email Field
                  activeTextFieldWithIcon('assets/email.png', 'E-mail'),
                  const SizedBox(height: 20),

                  // Updated Password Field
                  activeTextFieldWithIcon('assets/password.png', 'Password', obscureText: true),
                  const SizedBox(height: 16),

                  // Forgot Password
                  Center(
                    child: GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => const ForgotPasswordEmployer()),
                        );
                      },
                      child: Text(
                        'Forgot  Password?',
                        style: TextStyle(
                          color: Color(0xFF356899),
                          fontSize: 15,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w600,
                          letterSpacing: -0.5,
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 40),

                  // Login Button
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => HomeEmployer()),
                      );
                      // Handle login logic
                    },
                    child: Container(
                      width: double.infinity,
                      height: 60,
                      decoration: BoxDecoration(
                        color: Color(0xFF356899),
                        borderRadius: BorderRadius.circular(5),
                      ),
                      child: const Center(
                        child: Text(
                          'Login',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontFamily: 'Poppins',
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 40),

                  // Or continue with
                  Row(
                    children: [
                      const Expanded(
                        child: Divider(color: Color(0xFFAFB0B5), thickness: 0.5),
                      ),
                      const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 8),
                        child: Text(
                          'Or continue with',
                          style: TextStyle(
                            color: Color(0xFFAFB0B5),
                            fontSize: 13,
                            fontFamily: 'Circular Std',
                          ),
                        ),
                      ),
                      const Expanded(
                        child: Divider(color: Color(0xFFAFB0B5), thickness: 0.5),
                      ),
                    ],
                  ),

                  const SizedBox(height: 24),

                  // Social icons
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      socialIcon('assets/google.png'),
                      const SizedBox(width: 20),
                      socialIcon('assets/facebook.png'),
                      const SizedBox(width: 20),
                      socialIcon('assets/linkedin.png'),
                    ],
                  ),

                  const SizedBox(height: 40),

                  // Register prompt
                  Center(
                    child: Text.rich(
                      TextSpan(
                        children: [
                          const TextSpan(
                            text: 'Haven’t an account? ',
                            style: TextStyle(
                              color: Color(0xFFBDBEC2),
                              fontSize: 14,
                              fontFamily: 'Circular Std',
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                          TextSpan(
                            text: 'Register',
                            style: const TextStyle(
                              color: Color(0xFF356899),
                              fontSize: 14,
                              fontFamily: 'Circular Std',
                              fontWeight: FontWeight.w400,
                            ),
                            recognizer: TapGestureRecognizer()
                              ..onTap = () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => const Registeremployer(),
                                  ),
                                );
                              },
                          ),
                        ],
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),

                  const SizedBox(height: 40),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget activeTextFieldWithIcon(String assetPath, String hintText, {bool obscureText = false}) {
    return Container(
      width: double.infinity,
      height: 60,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        border: Border.all(color: const Color(0xFFAFB0B5)),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          Image.asset(
            assetPath,
            width: 40,
            height: 40,
            fit: BoxFit.contain,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: TextField(
              obscureText: obscureText,
              style: const TextStyle(
                fontSize: 14,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w500,
              ),
              decoration: InputDecoration(
                border: InputBorder.none,
                hintText: hintText,
                hintStyle: const TextStyle(
                  color: Color(0xFFAFB0B5),
                  fontSize: 14,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget socialIcon(String path) {
    return Container(
      width: 56,
      height: 56,
      decoration: const ShapeDecoration(
        color: Colors.white,
        shape: OvalBorder(),
        shadows: [
          BoxShadow(
            color: Color(0x05000000),
            blurRadius: 20,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Center(
        child: Image.asset(
          path,
          width: 30,
          height: 30,
          fit: BoxFit.contain,
        ),
      ),
    );
  }
}
