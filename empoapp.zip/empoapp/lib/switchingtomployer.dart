import 'package:flutter/material.dart';
import 'homeemployer.dart';

class SwitchingToEmployer extends StatefulWidget {
  const SwitchingToEmployer({super.key});

  @override
  State<SwitchingToEmployer> createState() => _SwitchingToEmployerState();
}

class _SwitchingToEmployerState extends State<SwitchingToEmployer>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<Offset> _topRightRectAnimation;
  late Animation<Offset> _topLeftCircleAnimation;
  late Animation<Offset> _bottomRightCircleAnimation;
  late Animation<Offset> _bottomLeftRectAnimation;
  late Animation<double> _loadingOpacityAnimation;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    );

    // Animate from right or left into position
    _topRightRectAnimation = Tween<Offset>(begin: const Offset(1.5, 0), end: Offset.zero)
        .animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));

    _topLeftCircleAnimation = Tween<Offset>(begin: const Offset(-1.5, 0), end: Offset.zero)
        .animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));

    _bottomRightCircleAnimation = Tween<Offset>(begin: const Offset(1.5, 0), end: Offset.zero)
        .animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));

    _bottomLeftRectAnimation = Tween<Offset>(begin: const Offset(-1.5, 0), end: Offset.zero)
        .animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));

    _loadingOpacityAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(CurvedAnimation(
      parent: _controller,
      curve: const Interval(0.5, 1.0),
    ));

    _controller.forward();

    Future.delayed(const Duration(seconds: 3), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const HomeEmployer()),
      );
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      body: Container(
        width: size.width,
        height: size.height,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment(0.5, 0.0),
            end: Alignment(0.5, 1.0),
            colors: [Color(0xFF356899), Color(0xFF1A334B)],
          ),
          borderRadius: BorderRadius.circular(0),
        ),
        child: Stack(
          children: [
            // Top Right Rectangle (comes from right)
            AnimatedBuilder(
              animation: _topRightRectAnimation,
              builder: (context, child) {
                return Positioned(
                  left: size.width * 0.6 + _topRightRectAnimation.value.dx * size.width,
                  top: size.height * 0.25,
                  child: Container(
                    width: size.width * 0.8,
                    height: 100,
                    decoration: ShapeDecoration(
                      color: const Color(0xFFDDBDA7),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(50),
                      ),
                    ),
                  ),
                );
              },
            ),

            // Top Left Circle (comes from left)
            AnimatedBuilder(
              animation: _topLeftCircleAnimation,
              builder: (context, child) {
                return Positioned(
                  left: size.width * 0.3 + _topLeftCircleAnimation.value.dx * size.width,
                  top: size.height * 0.25,
                  child: Container(
                    width: 100,
                    height: 100,
                    decoration: const ShapeDecoration(
                      color: Color(0xFFFE6D73),
                      shape: OvalBorder(),
                    ),
                  ),
                );
              },
            ),

            // Bottom Right Circle (comes from right)
            AnimatedBuilder(
              animation: _bottomRightCircleAnimation,
              builder: (context, child) {
                return Positioned(
                  left: size.width * 0.5 + _bottomRightCircleAnimation.value.dx * size.width,
                  top: size.height * 0.6,
                  child: Container(
                    width: 100,
                    height: 100,
                    decoration: const ShapeDecoration(
                      color: Color(0xFFDDBDA7),
                      shape: OvalBorder(),
                    ),
                  ),
                );
              },
            ),

            // Bottom Left Rectangle (comes from left)
            AnimatedBuilder(
              animation: _bottomLeftRectAnimation,
              builder: (context, child) {
                return Positioned(
                  left: -size.width * 0.35 + _bottomLeftRectAnimation.value.dx * size.width,
                  top: size.height * 0.6,
                  child: Container(
                    width: size.width * 0.8,
                    height: 100,
                    decoration: ShapeDecoration(
                      color: const Color(0xFFFE6D73),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(50),
                      ),
                    ),
                  ),
                );
              },
            ),

            // "Switching to Employer Mode..." Text instead of logo
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text(
                    'Switching to Employer Mode...',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Poppins',
                    ),
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),

            // Loading indicator
            Positioned(
              bottom: size.height * 0.1,
              left: 0,
              right: 0,
              child: AnimatedBuilder(
                animation: _loadingOpacityAnimation,
                builder: (context, child) {
                  return Opacity(
                    opacity: _loadingOpacityAnimation.value,
                    child: const Center(
                      child: CircularProgressIndicator(
                        valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
