import 'package:flutter/material.dart';
import 'homeemployer.dart';

class NotificationEmployer extends StatelessWidget {
  const NotificationEmployer({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAFAFD),
      appBar: AppBar(
        backgroundColor: const Color(0xFF3866E6),
        elevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            image: DecorationImage(
              image: AssetImage("assets/googlewallpaper.png"),
              fit: BoxFit.cover,
              colorFilter: ColorFilter.mode(
                Colors.white54, // ~50% white overlay
                BlendMode.srcOver,
              ),
            ),
          ),
        ),
        title: const Text(
          'Notifications',
          style: TextStyle(
            color: Color(0xFF0C0C26),
            fontSize: 20,
            fontWeight: FontWeight.w600,
          ),
        ),
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFF0C0C26)),
          onPressed: () {
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => const HomeEmployer()),
                  (Route<dynamic> route) => false,
            );
          },
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 16),
            _buildSectionHeader('Recent Activity'),
            const SizedBox(height: 16),
            _buildNotificationItem(
              avatar: 'assets/profile1.png',
              candidate: 'Mohamed Esso',
              message: 'accepted your interview invitation scheduled for Monday at 10AM.',
              time: '15 min ago',
              isNew: true,
            ),
            _buildNotificationItem(
              avatar: 'assets/profile2.png',
              candidate: 'Ahmad Skrill',
              message: 'submitted his application for the UX Designer role.',
              time: '1 hr ago',
              isNew: true,
            ),
            const SizedBox(height: 24),
            _buildSectionHeaderWithSeeAll('Interviews'),
            const SizedBox(height: 16),
            _buildNotificationItem(
              avatar: 'assets/profile3.png',
              candidate: 'Fatima Noor',
              message: 'confirmed availability for final round interview.',
              time: '2 hrs ago',
              isNew: false,
            ),
            _buildNotificationItem(
              avatar: 'assets/profile4.png',
              candidate: 'sarah shelby',
              message: 'rescheduled the interview for next Wednesday.',
              time: '5 hrs ago',
              isNew: false,
            ),
            const SizedBox(height: 24),
            _buildSectionHeaderWithSeeAll('Applications'),
            const SizedBox(height: 16),
            _buildNotificationItem(
              avatar: 'assets/profile5.png',
              candidate: 'Sofian Shbili',
              message: 'updated his portfolio and cover letter.',
              time: '1 day ago',
              isNew: false,
            ),
            _buildNotificationItem(
              avatar: 'assets/profile6.png',
              candidate: 'Abdallah Jerry',
              message: 'withdrew application for the Frontend Developer role.',
              time: '2 days ago',
              isNew: false,
            ),
            const SizedBox(height: 80),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Text(
      title,
      style: const TextStyle(
        color: Color(0xFF0C0C26),
        fontSize: 14,
        fontWeight: FontWeight.w600,
      ),
    );
  }

  Widget _buildSectionHeaderWithSeeAll(String title) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          title,
          style: const TextStyle(
            color: Color(0xFF0C0C26),
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
        Text(
          'See all',
          style: const TextStyle(
            color: Color(0xFF61636A),
            fontSize: 13,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }

  Widget _buildNotificationItem({
    required String avatar,
    required String candidate,
    required String message,
    required String time,
    required bool isNew,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CircleAvatar(
            radius: 23,
            backgroundImage: AssetImage(avatar),
            onBackgroundImageError: (_, __) => const Icon(Icons.person),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                RichText(
                  text: TextSpan(
                    children: [
                      TextSpan(
                        text: '$candidate ',
                        style: const TextStyle(
                          color: Color(0xFF0C0C26),
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      TextSpan(
                        text: message,
                        style: const TextStyle(
                          color: Color(0xFF94969D),
                          fontSize: 13,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Text(
                      time,
                      style: const TextStyle(
                        color: Color(0xFF94969D),
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    if (isNew) ...[
                      const SizedBox(width: 6),
                      Container(
                        width: 8,
                        height: 8,
                        decoration: const BoxDecoration(
                          color: Color(0xFF356899),
                          shape: BoxShape.circle,
                        ),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
