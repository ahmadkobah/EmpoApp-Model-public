import 'package:flutter/material.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAFAFD),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          TextButton(
            onPressed: () {
              // Edit profile functionality
            },
            child: const Text(
              'Edit',
              style: TextStyle(
                color: Color(0xFFAFB0B5),
                fontSize: 14,
                fontFamily: 'Circular Std',
                fontWeight: FontWeight.w400,
              ),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 25),
        child: Column(
          children: [
            _buildProfileHeader(),
            const SizedBox(height: 30),
            _buildStatsSection(),
            const SizedBox(height: 30),
            _buildExperienceSection(),
            const SizedBox(height: 20),
            _buildEducationSection(),
            const SizedBox(height: 20),
            _buildResumeSection(),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileHeader() {
    return Column(
      children: [
        const CircleAvatar(
          radius: 55,
          backgroundImage: AssetImage('assets/profile5.png'),
        ),
        const SizedBox(height: 20),

        // Name + Verification Icon
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              'Sofian Shbili',
              style: TextStyle(
                color: Color(0xFF0C0C26),
                fontSize: 20,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w600,
                height: 1.20,
                letterSpacing: -0.30,
              ),
            ),
            const SizedBox(width: 6),
            Container(
              padding: const EdgeInsets.all(2),
              decoration: const BoxDecoration(
                color: Color(0xFF007BFF), // Blue background
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.verified, // Use any verification icon you prefer
                color: Colors.white,
                size: 16,
              ),
            ),
          ],
        ),

        const SizedBox(height: 8),

        // Job Title
        const Text(
          'UX Designer',
          style: TextStyle(
            color: Color(0xFF94969D),
            fontSize: 12,
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w400,
            height: 1.60,
            letterSpacing: -0.12,
          ),
        ),

        const SizedBox(height: 8),

        // Gender
        Text(
          'Male',
          style: TextStyle(
            color: const Color(0xFF356899),
            fontSize: 14,
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w500,
            height: 1.50,
            letterSpacing: -0.14,
          ),
        ),
      ],
    );
  }


  Widget _buildStatsSection() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: const Color(0x07000000),
            blurRadius: 16,
            offset: const Offset(0, 4),
            spreadRadius: -20,
          )
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _buildStatItem('27', 'Applied'),
          _buildStatItem('19', 'Reviewed'),
          _buildStatItem('14', 'Interview'),
        ],
      ),
    );
  }

  Widget _buildStatItem(String value, String label) {
    return Column(
      children: [
        Text(
          value,
          style: const TextStyle(
            color: Color(0xFF0C0C26),
            fontSize: 16,
            fontFamily: 'Circular Std',
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: const TextStyle(
            color: Color(0xFF94969D),
            fontSize: 12,
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w400,
            height: 1.60,
            letterSpacing: -0.12,
          ),
        ),
      ],
    );
  }

  Widget _buildExperienceSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionHeader(title: 'Experience', onSeeAll: () {}),

        const SizedBox(height: 16),
        _buildExperienceItem(
          position: 'UX Designer',
          company: 'Google',
          location: 'Alexandria, Egypt',
          period: 'Dec 2022 - May 2025',
        ),
      ],
    );
  }

  Widget _buildEducationSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionHeader(title: 'Education', onSeeAll: () {}),

        const SizedBox(height: 16),
        _buildEducationItem(
          degree: 'Computer Science',
          institution: 'Bachelor | FUE',
          location: 'Cairo, Egypt',
          period: '2018 - 2022',
        ),
      ],
    );
  }

  Widget _buildResumeSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(
              'Resume',
              style: TextStyle(
                color: Color(0xFF0C0C26),
                fontSize: 16,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w600,
                height: 1.30,
                letterSpacing: -0.16,
              ),
            ),
            TextButton(
              onPressed: () {
                // Make a resume functionality
              },
              child: const Text(
                'Make a resume',
                style: TextStyle(
                  color: Color(0xFF356899),
                  fontSize: 13,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w400,
                  height: 1.60,
                  letterSpacing: -0.13,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              width: 1,
              color: const Color(0xFF356899),
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0x07000000),
                blurRadius: 16,
                offset: const Offset(0, 4),
                spreadRadius: -20,
              )
            ],
          ),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _buildResumeTag('CV', const Color(0xFF5386E4)),
                  const Column(
                    children: [
                      Text(
                        'Sofian Shbili',
                        style: TextStyle(
                          color: Color(0xFF0C0C26),
                          fontSize: 11,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w400,
                          letterSpacing: -0.22,
                        ),
                      ),
                      Text(
                        'UX Designer',
                        style: TextStyle(
                          color: Color(0xFF94969D),
                          fontSize: 8,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ],
                  ),
                  _buildResumeTag('PDF', const Color(0xFF356899)),
                ],
              ),
              const SizedBox(height: 16),
              const Text(
                'Creative UX Designer with 2+ years of experience in optimizing user experience through innovative solutions and dynamic interface designs. Successful in enhancing user engagement for well-known brands, providing a compelling user experience to improve brand loyalty and customer retention.',
                style: TextStyle(
                  color: Color(0xFF94969D),
                  fontSize: 12,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w400,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildSectionHeader({required String title, required VoidCallback onSeeAll}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          title,
          style: const TextStyle(
            color: Color(0xFF0C0C26),
            fontSize: 16,
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w600,
            height: 1.30,
            letterSpacing: -0.16,
          ),
        ),
        TextButton(
          onPressed: onSeeAll,
          child: const Text(
            'See all',
            style: TextStyle(
              color: Color(0xFFAFB0B5),
              fontSize: 13,
              fontFamily: 'Poppins',
              fontWeight: FontWeight.w400,
              height: 1.60,
              letterSpacing: -0.13,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildExperienceItem({
    required String position,
    required String company,
    required String location,
    required String period,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          width: 1,
          color: const Color(0xFF356899),
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0x07000000),
            blurRadius: 16,
            offset: const Offset(0, 4),
            spreadRadius: -20,
          )
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              image: const DecorationImage(
                image: AssetImage('assets/googlelogo2.png'), // replace with your actual path
                fit: BoxFit.cover,
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  position,
                  style: const TextStyle(
                    color: Color(0xFF0C0C26),
                    fontSize: 14,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w600,
                    height: 1.30,
                    letterSpacing: -0.14,
                  ),
                ),
                const SizedBox(height: 4),
                Opacity(
                  opacity: 0.5,
                  child: Text(
                    company,
                    style: const TextStyle(
                      color: Color(0xFF0C0C26),
                      fontSize: 12,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w400,
                      height: 1.60,
                      letterSpacing: -0.12,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                location,
                style: const TextStyle(
                  color: Color(0xFF0C0C26),
                  fontSize: 12,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w500,
                  height: 1.60,
                  letterSpacing: -0.12,
                ),
              ),
              const SizedBox(height: 4),
              Opacity(
                opacity: 0.5,
                child: Text(
                  period,
                  style: const TextStyle(
                    color: Color(0xFF0C0C26),
                    fontSize: 13,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w400,
                    height: 1.60,
                    letterSpacing: -0.13,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildEducationItem({
    required String degree,
    required String institution,
    required String location,
    required String period,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          width: 1,
          color: const Color(0xFF356899),
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0x07000000),
            blurRadius: 16,
            offset: const Offset(0, 4),
            spreadRadius: -20,
          )
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              image: const DecorationImage(
                image: AssetImage('assets/fue.jpeg'), // replace with your actual path
                fit: BoxFit.cover,
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  degree,
                  style: const TextStyle(
                    color: Color(0xFF0C0C26),
                    fontSize: 14,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w600,
                    height: 1.30,
                    letterSpacing: -0.14,
                  ),
                ),
                const SizedBox(height: 4),
                Opacity(
                  opacity: 0.5,
                  child: Text(
                    institution,
                    style: const TextStyle(
                      color: Color(0xFF0C0C26),
                      fontSize: 12,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w400,
                      height: 1.60,
                      letterSpacing: -0.12,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                location,
                style: const TextStyle(
                  color: Color(0xFF0C0C26),
                  fontSize: 12,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w500,
                  height: 1.60,
                  letterSpacing: -0.12,
                ),
              ),
              const SizedBox(height: 4),
              Opacity(
                opacity: 0.5,
                child: Text(
                  period,
                  style: const TextStyle(
                    color: Color(0xFF0C0C26),
                    fontSize: 13,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w400,
                    height: 1.60,
                    letterSpacing: -0.13,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildResumeTag(String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: ShapeDecoration(
        color: color,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(6),
        ),
      ),
      child: Text(
        label,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 8,
          fontFamily: 'Poppins',
          fontWeight: FontWeight.w400,
          letterSpacing: -0.08,
        ),
      ),
    );
  }
}