import 'package:flutter/material.dart';
import 'filteroptionemployer.dart';

class SearchOptionEmployer extends StatelessWidget {
  const SearchOptionEmployer({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAFAFD),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 25),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 52),
              const Center(
                child: Text(
                  'Search',
                  style: TextStyle(
                    color: Color(0xFF0C0C26),
                    fontSize: 16,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w600,
                    height: 1.30,
                    letterSpacing: -0.16,
                  ),
                ),
              ),
              const SizedBox(height: 40),
              _buildSearchBar(context),
              const SizedBox(height: 40),
              _buildSectionTitle('Recent Searches'),
              const SizedBox(height: 16),
              _buildRecentSearches(),
              const SizedBox(height: 40),
              _buildSectionTitle('Popular Roles'),
              const SizedBox(height: 16),
              _buildPopularRoles(),
              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSearchBar(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Container(
            height: 48,
            decoration: BoxDecoration(
              color: const Color(0xFFF1F1F2),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                width: 1,
                color: const Color(0xFF356899),
              ),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                const Icon(Icons.search, color: Color(0xFF94969D), size: 20),
                const SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    decoration: InputDecoration(
                      hintText: 'Search a job or position',
                      hintStyle: const TextStyle(
                        color: Color(0xFF94969D),
                        fontSize: 15,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w400,
                        height: 1.50,
                        letterSpacing: -0.15,
                      ),
                      border: InputBorder.none,
                    ),
                    style: const TextStyle(
                      color: Color(0xFF0C0C26),
                      fontSize: 15,
                      fontFamily: 'Poppins',
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(width: 12),
        GestureDetector(
          onTap: () {
            // Navigate to the FilterOption page
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => FilterOptionEmployer()),
            );
          },

          child: Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: const Color(0xFFF1F1F2),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                width: 1,
                color: const Color(0xFF356899),
              ),
            ),
            child: const Icon(Icons.filter_list, color: Color(0xFF3866E6)),
          ),
        ),
      ],
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      style: const TextStyle(
        color: Color(0xFF0C0C26),
        fontSize: 16,
        fontFamily: 'Poppins',
        fontWeight: FontWeight.w600,
        height: 1.30,
        letterSpacing: -0.16,
      ),
    );
  }

  Widget _buildRecentSearches() {
    final recentSearches = [
      'Product Manager',
      'UX Designer',
      'Product Designer',
    ];

    return Column(
      children: [
        for (var search in recentSearches)
          Column(
            children: [
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.history, color: Color(0xFF94969D)),
                title: Text(
                  search,
                  style: const TextStyle(
                    color: Color(0xFF94969D),
                    fontSize: 13,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w400,
                    height: 1.60,
                    letterSpacing: -0.13,
                  ),
                ),
                trailing: const Icon(Icons.arrow_forward_ios, size: 16, color: Color(0xFF94969D)),
              ),
              const Divider(height: 1, color: Color(0xFFC9CACE)),
            ],
          ),
      ],
    );
  }

  Widget _buildPopularRoles() {
    final popularRoles = [
      'Designer',
      'Administrate',
      'NGO',
      'Manager',
      'IT',
      'Management',
      'Marketing',
      'Developer',
      'SEO',
    ];

    return Wrap(
      spacing: 12,
      runSpacing: 12,
      children: [
        for (var role in popularRoles)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                width: 1,
                color: const Color(0xFF356899),
              ),
            ),
            child: Text(
              role,
              style: const TextStyle(
                color: Color(0xFF0C0C26),
                fontSize: 13,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w400,
                height: 1.60,
                letterSpacing: -0.13,
              ),
            ),
          ),
      ],
    );
  }
}