import 'package:flutter/material.dart';
import 'homescreen.dart';

class ResumePortfolio extends StatelessWidget {
  const ResumePortfolio({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAFAFD),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Center(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header Row
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      icon: Icon(Icons.arrow_back, color: Color(0xFF0C0C26)),
                      onPressed: () {
                        Navigator.pushAndRemoveUntil(
                          context,
                          MaterialPageRoute(builder: (context) => const HomeScreen()),
                              (Route<dynamic> route) => false, //
                        );
                      },
                    ),
                    const Text(
                      'Resume & Portfolio',
                      style: TextStyle(
                        color: Color(0xFF0C0C26),
                        fontSize: 16,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w600,
                        height: 1.30,
                        letterSpacing: -0.16,
                      ),
                    ),
                    Text(
                      'button',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w600,
                        height: 1.40,
                        letterSpacing: -0.13,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 32),

                // Section Title
                Text(
                  'Resume or CV',
                  style: TextStyle(
                    color: Color(0xFF0C0C26),
                    fontSize: 16,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w600,
                    height: 1.30,
                    letterSpacing: -0.16,
                  ),
                ),
                const SizedBox(height: 12),

                // Upload Container
                Container(
                  width: double.infinity,
                  height: 150,
                  decoration: BoxDecoration(
                    border: Border.all(color: Color(0xFF356899), width: 1),
                    borderRadius: BorderRadius.circular(24),
                  ),
                  child: Center(
                    child: Text(
                      'Upload CV here',
                      style: TextStyle(color: Colors.grey),
                    ),
                  ),
                ),
                const SizedBox(height: 20),

                // Description

                const SizedBox(height: 20),

                // Uploaded file card
                Container(
                  width: double.infinity,
                  height: 84,
                  padding: EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Color(0xFFF1F1F2),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(right: 12),
                        child: Image.asset(
                          'assets/pdf100.png',
                          width: 50,
                          height: 50,
                        ),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'CV_UX Designer',
                            style: TextStyle(
                              color: Color(0xFF0C0C26),
                              fontSize: 14,
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          SizedBox(height: 4),
                          Text(
                            '287 KB',
                            style: TextStyle(
                              color: Color(0xFF94969D),
                              fontSize: 11,
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 20),

                // Add More Button
                Center(
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Color(0xFF356899),
                      padding: const EdgeInsets.symmetric(horizontal: 48, vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    onPressed: () {},
                    child: Text(
                      'Add More',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.white,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 40),

                // Portfolio Title
                Text.rich(
                  TextSpan(
                    children: [
                      TextSpan(
                        text: 'Portfolio ',
                        style: TextStyle(
                          color: Color(0xFF0C0C26),
                          fontSize: 16,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w600,
                          letterSpacing: -0.16,
                        ),
                      ),
                      TextSpan(
                        text: '(Optional)',
                        style: TextStyle(
                          color: Color(0xFFAFB0B5),
                          fontSize: 16,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w400,
                          letterSpacing: -0.16,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),

                // Portfolio Buttons Grid
                Wrap(
                  spacing: 10,
                  runSpacing: 10,
                  children: [
                    _portfolioButton('Add Link'),
                    _portfolioButton('Add Photo'),
                    _portfolioButton('Add PDF'),
                    _portfolioButton('Add Slide'),
                  ],
                ),
                const SizedBox(height: 40),

                // Save Button
                Container(
                  width: double.infinity,
                  height: 61,
                  decoration: BoxDecoration(
                    color: Color(0xFF356899),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: TextButton(
                    onPressed: () {
                      Navigator.pushAndRemoveUntil(
                        context,
                        MaterialPageRoute(builder: (context) => const HomeScreen()),
                            (Route<dynamic> route) => false, //
                      );
                    },
                    child: Text(
                      'Save',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _portfolioButton(String text) {
    return Container(
      width: 184,
      height: 61,
      decoration: BoxDecoration(
        border: Border.all(color: Color(0xFF356899), width: 1),
        borderRadius: BorderRadius.circular(6),
        color: Colors.white,
      ),
      child: Center(
        child: Text(
          text,
          style: TextStyle(
            color: Colors.black,
            fontSize: 16,
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  }
}
