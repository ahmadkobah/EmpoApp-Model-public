import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'loginorregister.dart';
import 'login.dart';
import 'jobtype.dart';

class Register extends StatelessWidget {
  const Register({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAFAFD),
      body: Center(
        child: SingleChildScrollView(
          child: Container(
            width: 450,
            height: 834,
            clipBehavior: Clip.antiAlias,
            decoration: ShapeDecoration(
              color: const Color(0xFFFAFAFD),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(30),
              ),
            ),
            child: Stack(
              children: [
                // Back button
                Positioned(
                  left: 25,
                  top: 50,
                  child: GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const loginorregister(),
                        ),
                      );
                    },
                    child: const Icon(
                      Icons.arrow_back,
                      color: Color(0xFF0C0C26),
                      size: 32,
                    ),
                  ),
                ),

                Positioned(
                  left: 24,
                  top: 146,
                  child: Text(
                    'Registration',
                    style: TextStyle(
                      color: const Color(0xFF0C0C26),
                      fontSize: 24,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w600,
                      height: 1.40,
                      letterSpacing: -0.36,
                    ),
                  ),
                ),

                Positioned(
                  left: 24,
                  top: 187,
                  child: Opacity(
                    opacity: 0.40,
                    child: Text(
                      'Let’s Register. Apply to jobs!',
                      style: TextStyle(
                        color: const Color(0xFF0C0C26),
                        fontSize: 14,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w400,
                        height: 1.60,
                        letterSpacing: -0.14,
                      ),
                    ),
                  ),
                ),

                Positioned(
                  left: -25,
                  top: 105,
                  child: SizedBox(
                    width: 150,
                    child: Text(
                      'EmpÖ',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: const Color(0xFF356899),
                        fontSize: 22,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w600,
                        letterSpacing: -0.44,
                      ),
                    ),
                  ),
                ),

                // Full Name
                Positioned(
                  left: 10,
                  top: 240,
                  child: textFieldWithIcon('assets/fullname.png', 'Full Name'),
                ),

                // Email
                Positioned(
                  left: 10,
                  top: 320,
                  child: textFieldWithIcon('assets/email.png', 'E-mail'),
                ),

                // Password
                Positioned(
                  left: 10,
                  top: 400,
                  child: textFieldWithIcon('assets/password.png', 'Password', obscureText: true),
                ),

                // Confirm Password
                Positioned(
                  left: 10,
                  top: 480,
                  child: textFieldWithIcon('assets/password.png', 'Confirm Password', obscureText: true),
                ),

                // Register Button
                Positioned(
                  left: 4,
                  top: 579.08,
                  child: GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => const JobType()),
                      );
                    },
                    child: Container(
                      width: 400,
                      height: 65.93,
                      padding: const EdgeInsets.symmetric(horizontal: 48, vertical: 16),
                      decoration: ShapeDecoration(
                        color: const Color(0xFF356899),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const [
                          Text(
                            'Register',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w500,
                              height: 1.50,
                              letterSpacing: -0.16,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),

                // Login prompt
                Positioned(
                  bottom: 40,
                  left: 0,
                  right: 0,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: Text.rich(
                      TextSpan(
                        children: [
                          const TextSpan(
                            text: 'Already have an account? ',
                            style: TextStyle(
                              color: Color(0xFFBDBEC2),
                              fontSize: 14,
                              fontFamily: 'Circular Std',
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                          TextSpan(
                            text: 'Log in',
                            style: const TextStyle(
                              color: Color(0xFF356899),
                              fontSize: 14,
                              fontFamily: 'Circular Std',
                              fontWeight: FontWeight.w400,
                            ),
                            recognizer: TapGestureRecognizer()
                              ..onTap = () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(builder: (context) => const Login()),
                                );
                              },
                          ),
                        ],
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),

                // Social login section
                const Positioned(
                  left: 150,
                  top: 681,
                  child: SizedBox(
                    width: 108,
                    child: Text(
                      'Or continue with',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Color(0xFFAFB0B5),
                        fontSize: 13,
                        fontFamily: 'Circular Std',
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                  ),
                ),
                const Positioned(
                  left: 10,
                  top: 683,
                  child: SizedBox(
                    width: 107,
                    child: Divider(color: Color(0xFFAFB0B5), thickness: 0.5),
                  ),
                ),
                const Positioned(
                  left: 302,
                  top: 683,
                  child: SizedBox(
                    width: 107,
                    child: Divider(color: Color(0xFFAFB0B5), thickness: 0.5),
                  ),
                ),
                Positioned(left: 78, top: 710, child: googleIcon()),
                Positioned(left: 178, top: 710, child: facebookIcon()),
                Positioned(left: 278, top: 710, child: appleIcon()),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget textFieldWithIcon(String assetPath, String hintText, {bool obscureText = false}) {
    return Container(
      width: 400,
      height: 61.22,
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: ShapeDecoration(
        shape: RoundedRectangleBorder(
          side: const BorderSide(width: 1, color: Color(0xFFAFB0B5)),
          borderRadius: BorderRadius.circular(10),
        ),
      ),
      child: Row(
        children: [
          Image.asset(assetPath, width: 40, height: 40),
          const SizedBox(width: 10),
          Expanded(
            child: TextField(
              obscureText: obscureText,
              decoration: InputDecoration(
                border: InputBorder.none,
                hintText: hintText,
                hintStyle: const TextStyle(
                  color: Color(0xFFAFB0B5),
                  fontSize: 14,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w500,
                  height: 1.5,
                  letterSpacing: -0.14,
                ),
              ),
              style: const TextStyle(
                color: Colors.black,
                fontSize: 14,
                fontFamily: 'Poppins',
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget googleIcon() {
    return socialIcon('assets/google.png');
  }

  Widget facebookIcon() {
    return socialIcon('assets/facebook.png');
  }

  Widget appleIcon() {
    return socialIcon('assets/linkedin.png');
  }

  Widget socialIcon(String asset) {
    return Container(
      width: 56,
      height: 56,
      decoration: const ShapeDecoration(
        color: Colors.white,
        shape: OvalBorder(),
        shadows: [
          BoxShadow(
            color: Color(0x05000000),
            blurRadius: 20,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Center(
        child: Image.asset(
          asset,
          width: 30,
          height: 30,
          fit: BoxFit.contain,
        ),
      ),
    );
  }
}
