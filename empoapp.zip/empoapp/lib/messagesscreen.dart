import 'package:flutter/material.dart';
import 'homescreen.dart';

class MessagesScreen extends StatelessWidget {
  const MessagesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAFAFD),
      appBar: AppBar(
        backgroundColor: const Color(0xFF3866E6),
        elevation: 0,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(
              'Messages',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),
            Container(
              width: 24,
              height: 24,
              decoration: BoxDecoration(
                color: Colors.white.withAlpha(38),
                borderRadius: BorderRadius.circular(10),
              ),
              child: IconButton(
                padding: EdgeInsets.zero,
                icon: const Icon(Icons.edit, size: 20, color: Colors.white),
                onPressed: () {
                  // Add your new message functionality here
                  // For example: Navigator.push(context, MaterialPageRoute(builder: (_) => NewMessageScreen()));
                },
              ),
            ),
          ],
        ),
        centerTitle: false,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFF0C0C26)),
          onPressed: () {
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => const HomeScreen()),
                  (Route<dynamic> route) => false, // Clear all routes
            );
          },
        )
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
        children: [
          _buildSearchField(),
          const SizedBox(height: 24),
          _buildSectionHeader('Recent Chats'),
          const SizedBox(height: 16),
          _buildChatItem(
            name: 'Mohamed Esso',
            message: 'Hey! How about our project?',
            time: '10:30 AM',
            unread: true,
            avatar: 'assets/profile1.png',
          ),
          _buildChatItem(
            name: 'Ahmad Skrill',
            message: 'Meeting at 2pm tomorrow',
            time: 'Yesterday',
            unread: false,
            avatar: 'assets/profile2.png',
          ),
          _buildChatItem(
            name: 'Google Team',
            message: 'New job opportunity for you',
            time: '2 days ago',
            unread: true,
            avatar: 'assets/logogoogle20.png',
          ),
          const SizedBox(height: 24),
          _buildSectionHeader('Older Messages'),
          const SizedBox(height: 16),
          _buildChatItem(
            name: 'Fatima Noor',
            message: 'Thanks for your application',
            time: '1 week ago',
            unread: false,
            avatar: 'assets/profile3.png',
          ),
          _buildChatItem(
            name: 'LinkedIn',
            message: '5 new connection requests',
            time: '2 weeks ago',
            unread: false,
            avatar: 'assets/linkedinlogo20.png',
          ),
        ],
      ),
      // Bottom navigation bar removed - now handled by HomeScreen
    );
  }

  Widget _buildSearchField() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Color(0xFF3866E6), // Stroke color
          width: 1, // Stroke width
        ),
      ),
      child: Row(
        children: [
          const Icon(
            Icons.search,
            color: Color(0xFF94969D),
          ),
          const SizedBox(width: 10),
          const Expanded(
            child: TextField(
              decoration: InputDecoration(
                border: InputBorder.none,
                hintText: 'Search messages...',
                hintStyle: TextStyle(
                  color: Color(0xFF94969D),
                  fontSize: 14,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Text(
      title,
      style: const TextStyle(
        color: Color(0xFF0C0C26),
        fontSize: 16,
        fontWeight: FontWeight.w600,
      ),
    );
  }

  Widget _buildChatItem({
    required String name,
    required String message,
    required String time,
    required bool unread,
    required String avatar,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 24,
            backgroundImage: AssetImage(avatar),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: TextStyle(
                    color: const Color(0xFF0C0C26),
                    fontSize: 14,
                    fontWeight: unread ? FontWeight.w600 : FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  message,
                  style: TextStyle(
                    color: const Color(0xFF7A7C84),
                    fontSize: 12,
                    fontWeight: unread ? FontWeight.w500 : FontWeight.normal,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                time,
                style: TextStyle(
                  color: const Color(0xFF94969D),
                  fontSize: 10,
                ),
              ),
              if (unread) ...[
                const SizedBox(height: 8),
                Container(
                  width: 8,
                  height: 8,
                  decoration: const BoxDecoration(
                    color: Color(0xFF3866E6),
                    shape: BoxShape.circle,
                  ),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }
}