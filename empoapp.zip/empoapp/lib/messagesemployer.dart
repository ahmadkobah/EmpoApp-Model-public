import 'package:flutter/material.dart';
import 'homeemployer.dart';

class MessagesEmployer extends StatelessWidget {
  const MessagesEmployer({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAFAFD),
      appBar: AppBar(
        backgroundColor: const Color(0xFF3866E6),
        elevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            image: DecorationImage(
              image: AssetImage("assets/googlewallpaper.png"),
              fit: BoxFit.cover,
              colorFilter: ColorFilter.mode(
                Colors.white54, // ~50% white overlay
                BlendMode.srcOver,
              ),
            ),
          ),
        ),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(
              'Messages',
              style: TextStyle(
                color: Colors.black,
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),
            Container(
              width: 24,
              height: 24,
              decoration: BoxDecoration(
                color: Colors.white.withAlpha(38),
                borderRadius: BorderRadius.circular(10),
              ),
              child: IconButton(
                padding: EdgeInsets.zero,
                icon: const Icon(Icons.edit, size: 20, color: Colors.black),
                onPressed: () {
                  // Navigate to new message creation (e.g., to a candidate)
                },
              ),
            ),
          ],
        ),
        centerTitle: false,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFF0C0C26)),
          onPressed: () {
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => const HomeEmployer()),
                  (Route<dynamic> route) => false,
            );
          },
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
        children: [
          _buildSearchField(),
          const SizedBox(height: 24),
          _buildSectionHeader('Candidate Messages'),
          const SizedBox(height: 16),
          _buildChatItem(
            name: 'Mohamed Esso',
            message: 'I’m interested in the role you posted.',
            time: '09:45 AM',
            unread: true,
            avatar: 'assets/profile1.png',
          ),
          _buildChatItem(
            name: 'Google Admin',
            message: 'Your job post has been approved.',
            time: 'Yesterday',
            unread: false,
            avatar: 'assets/googlelogo2.png',
          ),
          const SizedBox(height: 24),
          _buildSectionHeader('Earlier'),
          const SizedBox(height: 16),
          _buildChatItem(
            name: 'Fatima Noor',
            message: 'Thank you for the interview opportunity.',
            time: '3 days ago',
            unread: false,
            avatar: 'assets/profile3.png',
          ),
          _buildChatItem(
            name: 'Support',
            message: 'Your ticket has been resolved.',
            time: '1 week ago',
            unread: false,
            avatar: 'assets/logobig.png',
          ),
        ],
      ),
    );
  }

  Widget _buildSearchField() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Color(0xFF3866E6),
          width: 1,
        ),
      ),
      child: Row(
        children: const [
          Icon(Icons.search, color: Color(0xFF94969D)),
          SizedBox(width: 10),
          Expanded(
            child: TextField(
              decoration: InputDecoration(
                border: InputBorder.none,
                hintText: 'Search candidate messages...',
                hintStyle: TextStyle(
                  color: Color(0xFF94969D),
                  fontSize: 14,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Text(
      title,
      style: const TextStyle(
        color: Color(0xFF0C0C26),
        fontSize: 16,
        fontWeight: FontWeight.w600,
      ),
    );
  }

  Widget _buildChatItem({
    required String name,
    required String message,
    required String time,
    required bool unread,
    required String avatar,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 24,
            backgroundImage: AssetImage(avatar),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: TextStyle(
                    color: const Color(0xFF0C0C26),
                    fontSize: 14,
                    fontWeight: unread ? FontWeight.w600 : FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  message,
                  style: TextStyle(
                    color: const Color(0xFF7A7C84),
                    fontSize: 12,
                    fontWeight: unread ? FontWeight.w500 : FontWeight.normal,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                time,
                style: const TextStyle(
                  color: Color(0xFF94969D),
                  fontSize: 10,
                ),
              ),
              if (unread) ...[
                const SizedBox(height: 8),
                Container(
                  width: 8,
                  height: 8,
                  decoration: const BoxDecoration(
                    color: Color(0xFF3866E6),
                    shape: BoxShape.circle,
                  ),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }
}
