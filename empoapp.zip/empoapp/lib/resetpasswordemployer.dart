import 'package:flutter/material.dart';
import 'loginorregisteremployer.dart';
import 'verifyemployee.dart';


class ResetPasswordEmployer extends StatefulWidget {
  const ResetPasswordEmployer({super.key});

  @override
  State<ResetPasswordEmployer> createState() => _ResetPasswordEmployerState();
}

class _ResetPasswordEmployerState extends State<ResetPasswordEmployer> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAFAFD),
      body: Center(
        child: SingleChildScrollView(
          child: Container(
            width: 450,
            height: 834,
            clipBehavior: Clip.antiAlias,
            decoration: ShapeDecoration(
              color: const Color(0xFFFAFAFD),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(30),
              ),
            ),
            child: Stack(
              children: [
                // Arrow Back
                Positioned(
                  left: 25,
                  top: 50,
                  child: GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const loginorregisteremployer(),
                        ),
                      );
                    },
                    child: const Icon(
                      Icons.arrow_back,
                      color: Color(0xFF0C0C26),
                      size: 32,
                    ),
                  ),
                ),

                // Logo
                Positioned(
                  top: 95,
                  left: 130,
                  child: SizedBox(
                    width: 150,
                    child: Text(
                      'EmpÖ',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: const Color(0xFF356899),
                        fontSize: 22,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w600,
                        letterSpacing: -0.44,
                      ),
                    ),
                  ),
                ),

                // Title
                const Positioned(
                  left: 125,
                  top: 165,
                  child: Text(
                    'Reset Password',
                    style: TextStyle(
                      color: Color(0xFF0C0C26),
                      fontSize: 24,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w600,
                      height: 1.40,
                      letterSpacing: -0.36,
                    ),
                  ),
                ),

                // Subtitle
                const Positioned(
                  left: 125,
                  top: 215,
                  child: Opacity(
                    opacity: 0.40,
                    child: Text(
                      'Enter your new password',
                      style: TextStyle(
                        color: Color(0xFF0C0C26),
                        fontSize: 14,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w400,
                        height: 1.60,
                        letterSpacing: -0.14,
                      ),
                    ),
                  ),
                ),

                // Email Field
                Positioned(
                  left: 5,
                  top: 300,
                  child: Container(
                    width: 400,
                    height: 61,
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(color: const Color(0xFFBDBEC2)),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.lock_outline, color: Color(0xFF356899)),
                        const SizedBox(width: 8),
                        const Expanded(
                          child: TextField(
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              hintText: 'Enter Your Password',
                              hintStyle: TextStyle(
                                color: Color(0xFFBDBEC2),
                                fontFamily: 'Poppins',
                                fontSize: 14,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                // New Password Field
                Positioned(
                  left: 5,
                  top: 380,
                  child: Container(
                    width: 400,
                    height: 61,
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(color: const Color(0xFFBDBEC2)),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.lock_outline, color: Color(0xFF356899)),
                        const SizedBox(width: 8),
                        const Expanded(
                          child: TextField(
                            obscureText: true,
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              hintText: 'Reenter New Password',
                              hintStyle: TextStyle(
                                color: Color(0xFFBDBEC2),
                                fontFamily: 'Poppins',
                                fontSize: 14,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                // Reset Password Button
                Positioned(
                  left: 5,
                  top: 480,
                  child: SizedBox(
                    width: 400,
                    height: 60,
                    child: ElevatedButton(
                      style: ButtonStyle(
                        backgroundColor: const WidgetStatePropertyAll(Color(0xFF356899)),
                        shape: const WidgetStatePropertyAll(
                          RoundedRectangleBorder(
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                          ),
                        ),
                      ),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const VerifyEmployee(),
                          ),
                        );
                      },
                      child: const Text(
                        'Reset Password',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w500,
                          height: 1.5,
                          letterSpacing: -0.16,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}