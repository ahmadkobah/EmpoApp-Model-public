import 'package:flutter/material.dart';
import 'splashscreen.dart';

void main() {
  runApp(const EmpoApp());
}

class EmpoApp extends StatelessWidget {
  const EmpoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'EmpoApp',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.blue, // Change to your brand color
          brightness: Brightness.light,
        ),
        useMaterial3: true,
      ),
      home: const SplashScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}