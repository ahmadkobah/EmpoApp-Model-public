import 'package:flutter/material.dart';
import 'confirmationemployee.dart';

class VerifyEmployee extends StatefulWidget {
  const VerifyEmployee({super.key});

  @override
  State<VerifyEmployee> createState() => _VerifyEmployeeState();
}

class _VerifyEmployeeState extends State<VerifyEmployee> {
  final List<FocusNode> _focusNodes = List.generate(4, (_) => FocusNode());
  final List<TextEditingController> _controllers =
  List.generate(4, (_) => TextEditingController());


  @override
  void dispose() {
    for (var node in _focusNodes) {
      node.dispose();
    }
    for (var controller in _controllers) {
      controller.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAFAFD),
      body: SafeArea(
        child: Center(
          child: Container(
            width: 450,
            height: 956,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(30),
            ),
            child: Stack(
              children: [
                // Logo / App Name
                Positioned(
                  left: 130,
                  top: 90,
                  child: SizedBox(
                    width: 150,
                    child: Text(
                      'EmpÖ',
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: Color(0xFF356899),
                        fontSize: 22,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w600,
                        letterSpacing: -0.44,
                      ),
                    ),
                  ),
                ),

                // Title
                const Positioned(
                  left: 125,
                  top: 150,
                  child: SizedBox(
                    width: 164.86,
                    height: 42.93,
                    child: Text(
                      'Verify Code',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Color(0xFF0C0C26),
                        fontSize: 24,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w600,
                        height: 1.40,
                        letterSpacing: -0.36,
                      ),
                    ),
                  ),
                ),

                // Description
                const Positioned(
                  left: 25,
                  top: 250,
                  child: SizedBox(
                    width: 371.54,
                    child: Opacity(
                      opacity: 0.40,
                      child: Text(
                        'Enter your verification code from your email or phone number that we’ve sent',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Color(0xFF0C0C26),
                          fontSize: 14,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w400,
                          height: 1.60,
                          letterSpacing: -0.14,
                        ),
                      ),
                    ),
                  ),
                ),

                // Code Input Fields
                Positioned(
                  top: 340,
                  left: 30,
                  right: 30,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: List.generate(4, (index) {
                      return SizedBox(
                        width: 62.12,
                        height: 56.74,
                        child: TextField(
                          controller: _controllers[index],
                          focusNode: _focusNodes[index],
                          keyboardType: TextInputType.number,
                          textAlign: TextAlign.center,
                          maxLength: 1,
                          style: const TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.w600,
                            color: Color(0xFF0C0C26),
                          ),
                          decoration: InputDecoration(
                            counterText: '',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: const BorderSide(
                                color: Color(0xFFAFB0B5),
                              ),
                            ),
                          ),
                          onChanged: (value) {
                            if (value.length == 1 && index < 3) {
                              FocusScope.of(context)
                                  .requestFocus(_focusNodes[index + 1]);
                            } else if (value.isEmpty && index > 0) {
                              FocusScope.of(context)
                                  .requestFocus(_focusNodes[index - 1]);
                            }
                          },
                        ),
                      );
                    }),
                  ),
                ),

                // Resend Text
                Positioned(
                  left: 120,
                  top: 450,
                  child: GestureDetector(
                    onTap: () {
                      // Add resend logic here
                    },
                    child: SizedBox(
                      width: 200.75,
                      height: 25,
                      child: Text.rich(
                        TextSpan(
                          children: [
                            const TextSpan(
                              text: 'Didn’t Receive Code, ',
                              style: TextStyle(
                                color: Color(0xFFAFB0B5),
                                fontSize: 14,
                                fontFamily: 'Poppins',
                                fontWeight: FontWeight.w500,
                                height: 1.50,
                                letterSpacing: -0.14,
                              ),
                            ),
                            TextSpan(
                              text: 'Resend',
                              style: const TextStyle(
                                color: Color(0xFF356899),
                                fontSize: 14,
                                fontFamily: 'Poppins',
                                fontWeight: FontWeight.w500,
                                height: 1.50,
                                letterSpacing: -0.14,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),

                // Verify Button
                Positioned(
                  bottom: 65,
                  left: 30,
                  right: 30,
                  child: ElevatedButton(
                    onPressed: () {
                      // Combine code
                      final code = _controllers.map((e) => e.text).join();
                      if (code.length == 4) {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const ConfirmationEmployee(),
                          ),
                        );
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Please enter the full code'),
                          ),
                        );
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF356899),
                      minimumSize: const Size.fromHeight(60),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(5),
                      ),
                    ),
                    child: const Text(
                      'Verify',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w500,
                        letterSpacing: -0.16,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
