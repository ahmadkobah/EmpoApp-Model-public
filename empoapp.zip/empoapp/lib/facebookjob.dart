import 'package:flutter/material.dart';
import 'homescreen.dart';
import 'applyscreen.dart';

class FacebookJob extends StatelessWidget {
  final List<String> requirements = [
    "Bachelor’s degree in Computer Science or related field.",
    "2+ years of product design experience.",
    "Strong understanding of interaction design principles.",
    "Experience working closely with engineers and product managers.",
    "Proficient in Figma, Sketch, and Adobe Creative Suite.",
    "Strong communication and collaboration skills.",
    "Portfolio demonstrating design thinking and execution.",
  ];

  FacebookJob({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF356899),
      body: Column(
        children: [
          _buildHeader(context),
          Expanded(child: _buildContent(context)),
        ],
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Container(
      height: 348,
      width: double.infinity,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(40),
          bottomRight: Radius.circular(40),
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 36),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(
                  icon: const Icon(Icons.arrow_back, color: Colors.black),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => HomeScreen()),
                    );
                  },
                ),
                const Icon(Icons.bookmark_add_outlined, color: Colors.black),
              ],
            ),

            const SizedBox(height: 10),
            CircleAvatar(
              radius: 42,
              backgroundColor: Colors.white,
              child: Image.asset('assets/facebook2.png', width: 50),
            ),
            const SizedBox(height: 10),
            const Text('Product Designer',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
            const Text('Facebook',
                style: TextStyle(fontSize: 16, color: Colors.black54)),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _buildTag('Design'),
                _buildTag('Full-Time'),
                _buildTag('Mid-Level'),
              ],
            ),
            const SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: const [
                  Text("55\$/h",
                      style:
                      TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                  Text("Cairo, Egypt",
                      style:
                      TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget _buildTag(String label) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 4),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0xFF356899),
        borderRadius: BorderRadius.circular(30),
      ),
      child:
      Text(label, style: const TextStyle(color: Colors.white, fontSize: 12)),
    );
  }

  Widget _buildContent(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildTabBar(),
          const SizedBox(height: 16),
          ...requirements.map((item) => _buildBullet(item)),
          const Spacer(),
          _buildApplyButton(context),
        ],
      ),
    );
  }

  Widget _buildTabBar() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: const [
        Text("Description", style: TextStyle(color: Colors.white)),
        Text("Requirement", style: TextStyle(fontWeight: FontWeight.bold)),
        Text("About", style: TextStyle(color: Colors.white)),
        Text("Reviews", style: TextStyle(color: Colors.white)),
      ],
    );
  }

  Widget _buildBullet(String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text("• ",
              style: TextStyle(fontSize: 20, color: Color(0xFF94969D))),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 14,
                height: 1.6,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildApplyButton(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) =>
                ApplyScreen(
                  jobTitle: 'Product Designer',
                  company: 'Facebook',
                  location: 'Cairo, Egypt',
                  salary: '55\$ /h',
                  companyLogo: const CircleAvatar(
                    backgroundColor: Colors.transparent,
                    backgroundImage: AssetImage('assets/facebook2.png'),
                  ),
                ),
          ),
        );
      },
      child: Container(
        width: double.infinity,
        height: 56,
        margin: const EdgeInsets.only(bottom: 24),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(8),
        ),
        child: const Center(
          child: Text(
            'Apply Now !',
            style: TextStyle(
              color: Color(0xFF356899),
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }
}