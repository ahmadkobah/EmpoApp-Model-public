import 'package:flutter/material.dart';
import 'loginemployer.dart';


class ConfirmationEmployee extends StatelessWidget {
  const ConfirmationEmployee({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Container(
          width: 450,
          height: 956,
          clipBehavior: Clip.antiAlias,
          decoration: ShapeDecoration(
            color: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(30),
            ),
          ),
          child: Stack(
            children: [
              // Logo or confirmation image
              Positioned(
                top: 304,
                left: 95,
                right: 95,
                child: Container(
                  width: 260,
                  height: 158,
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage('assets/confirm.png'), // Replace with your local image
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),

              // App name
              Positioned(
                top: 190,
                left: 0,
                right: 0,
                child: Center(
                  child: Text(
                    'EmpÖ',
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Color(0xFF356899),
                      fontSize: 22,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w600,
                      letterSpacing: -0.44,
                    ),
                  ),
                ),
              ),

              // Confirmation title
              Positioned(
                top: 543,
                left: 0,
                right: 0,
                child: Center(
                  child: Text(
                    'Confirmation',
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Color(0xFF0C0C26),
                      fontSize: 24,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w600,
                      letterSpacing: -0.36,
                    ),
                  ),
                ),
              ),

              // Confirmation description
              Positioned(
                top: 593,
                left: 40,
                right: 40,
                child: Center(
                  child: Opacity(
                    opacity: 0.6,
                    child: Text(
                      'Your password has been changed. Please log in with your new password.',
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: Color(0xFF0C0C26),
                        fontSize: 14,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w400,
                        height: 1.6,
                      ),
                    ),
                  ),
                ),
              ),

              // Login Button
              Positioned(
                bottom: 65,
                left: 25,
                right: 25,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const loginemployer(), // Make sure Login is imported
                      ),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF356899),
                    minimumSize: const Size.fromHeight(60),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(5),
                    ),
                  ),
                  child: const Text(
                    'Log in',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w500,
                      letterSpacing: -0.16,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
