import 'package:flutter/material.dart';
import 'filteroption.dart';
import 'messagesscreen.dart';
import 'saved.dart';
import 'login.dart';
import 'notificationsscreen.dart';
import 'searchoption.dart';
import 'profilepage.dart';
import 'switchingtomployer.dart';
import 'resumeportfolio.dart';
import 'application.dart';
import 'googlejob.dart';
import 'facebookjob.dart';
import 'settings.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;
  bool isEmployerMode = false;


  final List<Widget> _pages = [
    HomeContent(),
    MessagesScreen(),
    Saved(),
    NotificationsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: _buildNavigationDrawer(),
      backgroundColor: const Color(0xFFFAFAFD),
      body: _pages[_currentIndex],
      bottomNavigationBar: _buildBottomNavBar(),
    );
  }

  Widget _buildNavigationDrawer() {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          _buildUserHeader(),
          _buildNavigationItems(context),
          _buildRoleSwitcher(),

        ],
      ),
    );
  }

  Widget _buildUserHeader() {
    return UserAccountsDrawerHeader(
      decoration: BoxDecoration(
        color: Color(0xFF356899),
      ),
      accountName: Row(
        children: [
          const Text(
            'Sofian Shbili',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          const SizedBox(width: 6),
          Icon(
            Icons.verified_user,
            color: Colors.white,
            size: 18,
          ),
        ],
      ),
      accountEmail: GestureDetector(
        onTap: () {
          Navigator.pop(context);
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => ProfilePage()),
          );
        },
        child: const Text(
          'View Profile',
          style: TextStyle(color: Colors.white70),
        ),
      ),
      currentAccountPicture: const CircleAvatar(
        backgroundImage: AssetImage('assets/profile5.png'),
      ),
    );
  }


  Widget _buildNavigationItems(BuildContext context) {
    final menuItems = [
      {'title': 'Personal Info', 'icon': Icons.person},
      {'title': 'Applications', 'icon': Icons.assignment},
      {'title': 'Proposals', 'icon': Icons.description},
      {'title': 'Resumes', 'icon': Icons.article},
      {'title': 'Portfolio', 'icon': Icons.work},
      {'title': 'Cover Letters', 'icon': Icons.mail},
      {'title': 'Settings', 'icon': Icons.settings},
      {'title': 'Logout', 'icon': Icons.logout},
    ];

    return Column(
      children: menuItems.map((item) {
        return ListTile(
          leading: Icon(item['icon'] as IconData),
          title: Text(item['title'] as String),
          onTap: () {
            Navigator.pop(context);

            switch (item['title']) {
              case 'Resumes':
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ResumePortfolio()),
                );
                break;
              case 'Portfolio':
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ResumePortfolio()),
                );
                break;
              case 'Applications':
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Application()),
                );
                break;
              case 'Settings':
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Settings()),
                );
                break;
              case 'Logout':
                _showLogoutConfirmation();
                break;
            // Add other cases here if needed
            }
          },
        );
      }).toList(),
    );
  }


  Widget _buildRoleSwitcher() {
    return Stack(
      children: [
        // Switcher background
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          width: double.infinity,
          height: 48,
          decoration: ShapeDecoration(
            color: const Color(0xFFF1F5FC),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
          ),
        ),

        // Active tab indicator
        AnimatedPositioned(
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeInOut,
          left: isEmployerMode ? MediaQuery.of(context).size.width / 2 : 16,
          top: 8,
          child: Container(
            width: 125,
            height: 36,
            decoration: ShapeDecoration(
              color: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
            ),
          ),
        ),

        // Row with both options
        Row(
          children: [
            Expanded(
              child: GestureDetector(
                onTap: () {
                  setState(() {
                    isEmployerMode = false;
                  });
                },
                child: Container(
                  alignment: Alignment.center,
                  height: 48,
                  child: Text(
                    'Employee Mode',
                    style: TextStyle(
                      color: !isEmployerMode
                          ? const Color(0xFF0C0C26)
                          : const Color(0xFFBDBEC2),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ),
            ),
            Expanded(
              child: GestureDetector(
                onTap: () {
                  setState(() {
                    isEmployerMode = true;
                  });
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => SwitchingToEmployer()),
                  );
                },
                child: Container(
                  alignment: Alignment.center,
                  height: 48,
                  child: Text(
                    'Employer Mode',
                    style: TextStyle(
                      color: isEmployerMode
                          ? const Color(0xFF0C0C26)
                          : const Color(0xFFBDBEC2),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }


  void _showLogoutConfirmation() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Logout'),
        content: const Text('Are you sure you want to logout?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => Login()),
              );
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Logged out successfully')),
              );
            },
            child: const Text('Logout'),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomNavBar() {
    return Container(
      height: 70,
      padding: const EdgeInsets.only(bottom: 10),
      child: Column(
        children: [
          const SizedBox(height: 4),
          Container(
            width: 305,
            height: 56,
            decoration: ShapeDecoration(
              color: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(45),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildNavIcon(Icons.home, 0),
                _buildNavIcon(Icons.message, 1),
                _buildNavIcon(Icons.bookmark, 2),
                _buildNavIcon(Icons.notifications, 3),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNavIcon(IconData icon, int index) {
    bool isActive = _currentIndex == index;
    return GestureDetector(
      onTap: () => setState(() => _currentIndex = index),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            icon,
            size: 24,
            color: isActive ? const Color(0xFF3866E6) : Colors.grey,
          ),
          const SizedBox(height: 2),
          if (isActive)
            Container(
              width: 4,
              height: 4,
              decoration: const BoxDecoration(
                color: Color(0xFF356899),
                shape: BoxShape.circle,
              ),
            ),
        ],
      ),
    );
  }
}


class HomeContent extends StatelessWidget {
  const HomeContent({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          Container(
            height: 150,
            width: double.infinity,
            decoration: const BoxDecoration(
              color: Color(0xFF3866E6),
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(28),
                bottomRight: Radius.circular(28),
              ),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 40),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Welcome Back!',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(height: 18),
                      const Text(
                        'Sofian Shbili 👋',
                        style: TextStyle(
                          color: Color(0xFF0C0C26),
                          fontSize: 22,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
                const CircleAvatar(
                  radius: 32,
                  backgroundImage: AssetImage('assets/profile5.png'),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => SearchOption()),
                      );
                    },
                    child: Container(
                      width: 48,
                      height: 48,
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: Color(0xFF3866E6),
                          width: 1,
                        ),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.search, color: Color(0xFF3866E6)),
                          const SizedBox(width: 10),
                          const Text(
                            'Search a job or position',
                            style: TextStyle(
                              color: Colors.grey,
                              fontSize: 14,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                GestureDetector(
                  onTap: () {
                    // Navigate to the FilterOption page
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => FilterOption()),
                    );
                  },

                  child: Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        width: 1,
                        color: const Color(0xFF3866E6),
                      ),
                    ),
                    child: const Icon(Icons.filter_list, color: Color(0xFF3866E6)),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 32),
          sectionHeader("Featured Jobs"),
          const SizedBox(height: 16),
          featuredJobs(context),
          const SizedBox(height: 32),
          sectionHeader("Recommended Jobs"),
          const SizedBox(height: 16),
          recommendedJobs(context),
          const SizedBox(height: 80),
        ],
      ),
    );
  }

  Widget sectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: Color(0xFF0C0C26),
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),
          const Text(
            'See all',
            style: TextStyle(
              color: Color(0xFF94969D),
              fontSize: 13,
            ),
          )
        ],
      ),
    );
  }

  Widget featuredJobs(BuildContext context) {
    return SizedBox(
      height: 220,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 24),
        children: [
          jobCard(
            bgColor: const Color(0xFF3866E6),
            title: "Product Designer",
            company: "Google",
            tags: const ["Design", "Full-Time", "Junior"],
            price: "55\$ /H",
            location: "Cairo / Egypt",
            imagePath: "assets/googlelogo48.png",
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => GoogleJob()),
              );
            },
          ),
          const SizedBox(width: 16),
          jobCard(
            bgColor: const Color(0xFF0C0C26),
            title: "Product Manager",
            company: "Google",
            tags: const ["Data", "Full-Time","Senior"],
            price: "45\$ /H",
            location: "Alexandria / Egypt",
            imagePath: "assets/googlelogo48.png",
            onTap: () {  },
          ),
        ],
      ),
    );
  }

  Widget jobCard({
    required Color bgColor,
    required String title,
    required String company,
    required List<String> tags,
    required String price,
    required String location,
    required String imagePath,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 280,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: BorderRadius.circular(24),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: const BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
              ),
              child: Center(
                child: SizedBox(
                  width: 48,
                  height: 48,
                  child: Image.asset(
                    imagePath,
                    fit: BoxFit.contain,
                    errorBuilder: (context, error, stackTrace) =>
                    const Icon(Icons.business, size: 48),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              title,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              company,
              style: TextStyle(
                color: Colors.white.withAlpha(191),
                fontSize: 14,
              ),
            ),
            const SizedBox(height: 16),
            Wrap(
              spacing: 8,
              children: tags
                  .map(
                    (tag) => Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.white.withAlpha(38),
                    borderRadius: BorderRadius.circular(65),
                  ),
                  child: Text(
                    tag,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 11,
                    ),
                  ),
                ),
              )
                  .toList(),
            ),
            const Spacer(),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  price,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                Text(
                  location,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget recommendedJobs(BuildContext context) {
    return Padding(

      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Row(
        children: [
          recommendedCard(
            bgColor: const Color(0xFFDDF5DC),
            title: "Sr Developer",
            company: "Spotify",
            price: "75/H",
            imagePath: "assets/spotify-logo-5434.png",
            onTap: () {  },
          ),
          const SizedBox(width: 16),
          recommendedCard(
            bgColor: const Color(0xFFEAF1FF),
            title: "Product Designer",
            company: "Facebook",
            price: "55/H",
            imagePath: "assets/facebooklogo.png",
            onTap: () { Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => FacebookJob()),
            );
              },
          ),
        ],
      ),
    );
  }

  Widget recommendedCard({
    required Color bgColor,
    required String title,
    required String company,
    required String price,
    required String imagePath,
    required VoidCallback onTap,
  }) {
    //return GestureDetector(
       // onTap: onTap,

    return Expanded(
        child: GestureDetector(
        onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 24),
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: BorderRadius.circular(24),
        ),
        child: Column(
          children: [
            Image.asset(
              imagePath,
              width: 36,
              height: 36,
              errorBuilder: (context, error, stackTrace) => const Icon(Icons.error),
            ),
            const SizedBox(height: 12),
            Text(
              title,
              style: const TextStyle(
                fontWeight: FontWeight.w600,
                color: Color(0xFF0C0C26),
              ),
            ),
            const SizedBox(height: 4),
            Text(
              company,
              style: const TextStyle(color: Color(0xFF7A7C84)),
            ),
            const SizedBox(height: 8),
            Text(
              price,
              style: const TextStyle(
                fontWeight: FontWeight.w500,
                color: Color(0xFF0C0C26),
              ),
            ),
          ],
        ),
      ),
      ),
    );
  }
}

// Simple placeholder for other tabs
class PlaceholderScreen extends StatelessWidget {
  final String title;

  const PlaceholderScreen({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        title,
        style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
      ),
    );
  }
}