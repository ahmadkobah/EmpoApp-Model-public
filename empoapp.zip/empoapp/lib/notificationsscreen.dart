import 'package:flutter/material.dart';
import 'homescreen.dart'; // Make sure this points to your HomeScreen

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAFAFD),
      appBar: AppBar(
        title: const Text(
          'Notifications',
          style: TextStyle(
            color: Color(0xFF0C0C26),
            fontSize: 20,
            fontWeight: FontWeight.w600,
          ),
        ),
        centerTitle: true,
        elevation: 0,
        backgroundColor: const Color(0xFFFAFAFD),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFF0C0C26)),
          onPressed: () {
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => const HomeScreen()),
                  (Route<dynamic> route) => false,
            );
          },
        ),
        actions: [
          
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 16),
            _buildSectionHeader('New activity'),
            const SizedBox(height: 16),
            _buildNotificationItem(
              avatar: 'assets/facebook.png',
              company: 'Facebook',
              message: 'want to take a final interview of you where head of HR will see you!',
              time: '12 min ago',
              isNew: true,
            ),
            _buildNotificationItem(
              avatar: 'assets/logogoogle20.png',
              company: 'Google',
              message: 'want to contact with you in 24 hours with proper preparation',
              time: '47 min ago',
              isNew: true,
            ),
            const SizedBox(height: 24),
            _buildSectionHeaderWithSeeAll('Applications'),
            const SizedBox(height: 16),
            _buildNotificationItem(
              avatar: 'assets/bmw20.png',
              company: 'BMW',
              message: 'Your application is submitted successfully. You can check the status here.',
              time: '1 hrs ago',
              isNew: false,
            ),
            _buildNotificationItem(
              avatar: 'assets/booking20.png',
              company: 'Booking.com',
              message: 'reviewing your application, cover letter and portfolio. All the best!',
              time: '3 hrs ago',
              isNew: false,
            ),
            const SizedBox(height: 24),
            _buildSectionHeaderWithSeeAll('Interview'),
            const SizedBox(height: 16),
            _buildNotificationItem(
              avatar: 'assets/logogoogle20.png',
              company: 'Google',
              message: 'liked your resume and want to take an interview of you.',
              time: '4 hrs ago',
              isNew: false,
            ),
            _buildNotificationItem(
              avatar: 'assets/facebook.png',
              company: 'Facebook',
              message: 'Congratulations! You passed the first round. Be prepare for next!',
              time: '6 hrs ago',
              isNew: false,
            ),
            const SizedBox(height: 80),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Text(
      title,
      style: const TextStyle(
        color: Color(0xFF0C0C26),
        fontSize: 14,
        fontWeight: FontWeight.w600,
      ),
    );
  }

  Widget _buildSectionHeaderWithSeeAll(String title) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          title,
          style: const TextStyle(
            color: Color(0xFF0C0C26),
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
        Text(
          'See all',
          style: const TextStyle(
            color: Color(0xFF61636A),
            fontSize: 13,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }

  Widget _buildNotificationItem({
    required String avatar,
    required String company,
    required String message,
    required String time,
    required bool isNew,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CircleAvatar(
            radius: 23,
            backgroundImage: AssetImage(avatar),
            onBackgroundImageError: (_, __) => const Icon(Icons.business),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                RichText(
                  text: TextSpan(
                    children: [
                      TextSpan(
                        text: '$company ',
                        style: const TextStyle(
                          color: Color(0xFF0C0C26),
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      TextSpan(
                        text: message,
                        style: const TextStyle(
                          color: Color(0xFF94969D),
                          fontSize: 13,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Text(
                      time,
                      style: const TextStyle(
                        color: Color(0xFF94969D),
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    if (isNew) ...[
                      const SizedBox(width: 6),
                      Container(
                        width: 8,
                        height: 8,
                        decoration: const BoxDecoration(
                          color: Color(0xFF356899),
                          shape: BoxShape.circle,
                        ),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}