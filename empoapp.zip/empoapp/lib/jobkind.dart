import 'package:flutter/material.dart';
import 'homescreen.dart';

class JobKind extends StatefulWidget {
  const JobKind({super.key});

  @override
  State<JobKind> createState() => _JobKindState();
}

class _JobKindState extends State<JobKind> {
  final List<String> jobKinds = [
    'Full - Time',
    'Part - Time',
    'Contract',
    'Intership',
    'Freelance',
    'School Training',
  ];

  final List<String> icons = [
    'assets/fulltime.png',
    'assets/parttime.png',
    'assets/contract.png',
    'assets/intership.png',
    'assets/freelance.png',
    'assets/schooltraining.png',
  ];

  final Set<int> selectedIndexes = {};

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAFAFD),
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 80),

            // Header with back button and app name
            const Center(
              child: Text(
                'EmpÖ',
                style: TextStyle(
                  color: Color(0xFF356899),
                  fontSize: 22,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w600,
                  letterSpacing: -0.44,
                ),
              ),
            ),

            const SizedBox(height: 50),

            // Title
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 30),
              child: Text(
                'What kind of job you\'re looking for?',
                style: TextStyle(
                  color: Color(0xFF0C0C26),
                  fontSize: 24,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w600,
                  height: 1.40,
                  letterSpacing: -0.36,
                ),
              ),
            ),

            const SizedBox(height: 30),

            // Job Type List
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 22),
                child: ListView.builder(
                  itemCount: jobKinds.length,
                  itemBuilder: (context, index) {
                    final isSelected = selectedIndexes.contains(index);
                    return Container(
                      height: 65,
                      margin: const EdgeInsets.only(bottom: 15),
                      decoration: BoxDecoration(
                        color: isSelected ? const Color(0xFF356899) : Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: const [
                          BoxShadow(
                            color: Color(0x050C1526),
                            blurRadius: 10,
                            offset: Offset(0, 2),
                            spreadRadius: -2,
                          ),
                        ],
                      ),
                      child: ListTile(
                        contentPadding: const EdgeInsets.symmetric(horizontal: 16),
                        leading: SizedBox(
                          width: 40,
                          height: 40,
                          child: Image.asset(
                            icons[index],
                            fit: BoxFit.contain,
                          ),
                        ),
                        title: Text(
                          jobKinds[index],
                          style: TextStyle(
                            color: isSelected ? Colors.white : const Color(0xFF0C0C26),
                            fontSize: 14,
                            fontFamily: 'Poppins',
                            fontWeight: FontWeight.w400,
                            height: 1.50,
                            letterSpacing: -0.16,
                          ),
                        ),
                        trailing: Container(
                          width: 18,
                          height: 18,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: isSelected ? Colors.white : const Color(0xFFC9CACE),
                              width: 1,
                            ),
                            color: isSelected ? const Color(0xFF356899) : null,
                          ),
                          child: isSelected
                              ? const Icon(Icons.check, size: 12, color: Colors.white)
                              : null,
                        ),
                        onTap: () {
                          setState(() {
                            if (isSelected) {
                              selectedIndexes.remove(index);
                            } else {
                              selectedIndexes.add(index);
                            }
                          });
                        },
                      ),
                    );
                  },
                ),
              ),
            ),

            // Save Button
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 20),
              child: ElevatedButton(
                onPressed: selectedIndexes.isNotEmpty
                    ? () {
                  Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => HomeScreen()),
                  );
                  }
                    : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF356899),
                  minimumSize: const Size.fromHeight(55),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(5),
                  ),
                ),
                child: const Text(
                  'Save',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w500,
                    height: 1.50,
                    letterSpacing: -0.16,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
