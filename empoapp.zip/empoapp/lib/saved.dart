import 'package:flutter/material.dart';
import 'homescreen.dart';

class Saved extends StatelessWidget {
  const Saved({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAFAFD),
      appBar: AppBar(
        title: const Text(
          'Saved',
          style: TextStyle(
            color: Color(0xFF0C0C26),
            fontSize: 20,
            fontWeight: FontWeight.w600,
          ),
        ),
        centerTitle: true,
        elevation: 0,
        backgroundColor: const Color(0xFFFAFAFD),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFF0C0C26)),
          onPressed: () {
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => const HomeScreen()),
                  (Route<dynamic> route) => false,
            );
          },
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16.0),
            child: CircleAvatar(
              radius: 20,
              backgroundColor: Colors.transparent,
              backgroundImage: AssetImage('assets/profile5.png'),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 24),
            _buildHeaderText(),
            const SizedBox(height: 24),
            _buildCategoryFilters(),
            const SizedBox(height: 24),
            _buildJobList(),
          ],
        ),
      ),
    );
  }

  Widget _buildHeaderText() {
    return RichText(
      text: const TextSpan(
        style: TextStyle(
          fontSize: 24,
          fontFamily: 'Poppins',
          fontWeight: FontWeight.w400,
          height: 1.4,
          color: Colors.black,
        ),
        children: [
          TextSpan(text: 'You '),
          TextSpan(text: 'saved'),
          TextSpan(text: ' 48 Jobs 👍'),
        ],
      ),
    );
  }

  Widget _buildCategoryFilters() {
    const List<String> categories = ['Design', 'All', 'Developer', 'Manager'];
    int selectedIndex = 0;

    return SizedBox(
      height: 36,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: categories.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, index) {
          final isSelected = index == selectedIndex;
          return GestureDetector(
            onTap: () {
              // You can add state logic here if you convert to StatefulWidget
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
              decoration: BoxDecoration(
                color: isSelected ? const Color(0xFF356899) : Colors.transparent,
                borderRadius: BorderRadius.circular(97),
                border: Border.all(
                  color: isSelected ? Colors.transparent : const Color(0xFF94969D),
                  width: 1,
                ),
              ),
              child: Text(
                categories[index],
                style: TextStyle(
                  color: isSelected ? Colors.white : const Color(0xFF94969D),
                  fontSize: 14,
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildJobList() {
    final List<Map<String, dynamic>> jobs = [
      {
        'title': 'UX Designer',
        'company': 'Spotify',
        'salary': '46/h',
        'location': 'Dubai, UAE',
        'type': 'Full-Time',
        'status': 'Closed',
        'statusColor': const Color(0xFFB2215A),
        'bgColor': const Color(0xFFFFEDED),
        'imagePath': "assets/spotify-logo-5434.png",
      },
      {
        'title': 'UX Designer',
        'company': 'Dribbble',
        'salary': '40/h',
        'location': 'Cairo, Egypt',
        'type': 'Full-Time',
        'status': 'Open',
        'statusColor': const Color(0xFF0E9D57),
        'bgColor': const Color(0xFFE8FDF2),
        'imagePath': "assets/dribble32.png",
      },
      {
        'title': 'UX Designer',
        'company': 'Facebook',
        'salary': '55/h',
        'location': 'Cairo, Egypt',
        'type': 'Full-Time',
        'status': 'Applied',
        'statusColor': const Color(0xFF0E4B9D),
        'bgColor': const Color(0xFFE8F6FD),
        'imagePath': "assets/facebooklogo.png",
      },
    ];

    return Column(
      children: jobs.map((job) => _buildJobCard(job)).toList(),
    );
  }

  Widget _buildJobCard(Map<String, dynamic> job) {
    return Container(
      width: double.infinity,
      height: 140,
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(
          color: const Color(0xFF356899),
          width: 1,
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage(job['imagePath']),
                fit: BoxFit.cover,
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  job['title'],
                  style: const TextStyle(
                    color: Color(0xFF0C0C26),
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Opacity(
                  opacity: 0.5,
                  child: Text(
                    job['company'],
                    style: const TextStyle(
                      color: Color(0xFF0C0C26),
                      fontSize: 12,
                    ),
                  ),
                ),
                const Spacer(),
                Container(
                  width: 140,
                  height: 35,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: job['bgColor'],
                    borderRadius: BorderRadius.circular(50),
                  ),
                  child: Text(
                    job['status'],
                    style: TextStyle(
                      color: job['statusColor'],
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '\$${job['salary']}',
                style: const TextStyle(
                  color: Color(0xFF0C0C26),
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 4),
              Opacity(
                opacity: 0.5,
                child: Text(
                  job['location'],
                  style: const TextStyle(
                    color: Color(0xFF0C0C26),
                    fontSize: 13,
                  ),
                ),
              ),
              const Spacer(),
              Text(
                job['type'],
                style: const TextStyle(
                  color: Color(0xFF0C0C26),
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
