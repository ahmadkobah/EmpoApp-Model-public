import 'package:flutter/material.dart';
import 'loginemployer.dart';
import 'registeremployer.dart';

class loginorregisteremployer extends StatelessWidget {
  const loginorregisteremployer({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAFAFD),
      body: MediaQuery.removePadding(
        context: context,
        removeTop: true,
        child: Center(
          child: SingleChildScrollView(
            child: Container(
              width: 450,
              height: 964,
              clipBehavior: Clip.antiAlias,
              decoration: ShapeDecoration(
                color: const Color(0xFFFAFAFD),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
              child: Stack(
                children: [
                  // Background Circle
                  Positioned(
                    left: -20,
                    top: -275,
                    child: Opacity(
                      opacity: 0.20,
                      child: Container(
                        width: 450,
                        height: 450,
                        decoration: const ShapeDecoration(
                          color: Color(0xFF224261),
                          shape: OvalBorder(),
                        ),
                      ),
                    ),
                  ),

                  // Logo Text
                  const Positioned(
                    left: 130,
                    top: 100,
                    child: SizedBox(
                      width: 150,
                      child: Text(
                        'EmpÖ',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Color(0xFF356899),
                          fontSize: 32,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w600,
                          letterSpacing: -0.64,
                        ),
                      ),
                    ),
                  ),

                  // Tagline
                  const Positioned(
                    left: 65,
                    top: 250,
                    child: SizedBox(
                      width: 281,
                      height: 39,
                      child: Text(
                        'Let’s find the best Employee for you!',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Color(0xFF95969D),
                          fontSize: 16,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w600,
                          letterSpacing: -0.32,
                        ),
                      ),
                    ),
                  ),

                  // Login Button

                  Positioned(
                    left: 6,
                    top: 370,
                    child: GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const loginemployer(),
                          ),
                        );
                      },
                      child: Container(
                        width: 400,
                        height: 60,
                        decoration: BoxDecoration(
                          color: const Color(0xFF356899),
                          borderRadius: BorderRadius.circular(5),
                        ),
                        child: const Center(
                          child: Text(
                            'Login',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w500,
                              letterSpacing: -0.16,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),

                  // Register Button
                  Positioned(
                    left: 6,
                    top: 470,
                    child: GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const Registeremployer(),
                          ),
                        );
                      },
                      child: Container(
                        width: 400,
                        height: 60,
                        decoration: BoxDecoration(
                          color: const Color(0xFF356899),
                          borderRadius: BorderRadius.circular(5),
                        ),
                        child: const Center(
                          child: Text(
                            'Register',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w500,
                              letterSpacing: -0.16,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
