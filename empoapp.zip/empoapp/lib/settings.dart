import 'package:flutter/material.dart';

import 'homescreen.dart';

class Settings extends StatelessWidget {
  const Settings({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Settings',
          style: TextStyle(color: Colors.black),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => const HomeScreen()),
                  (Route<dynamic> route) => false,
            );
          },
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16.0),
            child: CircleAvatar(
              radius: 18,
              backgroundImage: AssetImage('assets/profile5.png'), // replace with your asset
            ),
          ),
        ],
      ),
      backgroundColor: Colors.white,
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text(
            'Applications',
            style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black54),
          ),
          const SizedBox(height: 10),

          _buildSettingsTile(Icons.person_outline, 'Profile Visibility'),
          _buildSettingsTile(Icons.notifications_none, 'Notification'),
          _buildSettingsTile(Icons.lock_outline, 'Change Password'),
          _buildSettingsTile(Icons.language, 'Language'),
          _buildSettingsTile(Icons.brightness_6_outlined, 'Theme'),
          _buildSettingsTile(Icons.delete_outline, 'Delete Account', isDestructive: true),

          const SizedBox(height: 30),
          const Text(
            'About',
            style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black54),
          ),
          const SizedBox(height: 10),

          _buildSettingsTile(Icons.privacy_tip_outlined, 'Privacy'),
          _buildSettingsTile(Icons.article_outlined, 'Terms and conditions'),
          _buildSettingsTile(Icons.help_outline, 'Help Center'),
          _buildSettingsTile(Icons.support_agent_outlined, 'Support'),
          _buildSettingsTile(Icons.info_outline, 'About'),
        ],
      ),
    );
  }

  Widget _buildSettingsTile(IconData icon, String title, {bool isDestructive = false}) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 0, vertical: 4),
      leading: Icon(icon, color: isDestructive ? Colors.red : Colors.black54),
      title: Text(
        title,
        style: TextStyle(
          color: isDestructive ? Colors.red : Colors.black,
          fontWeight: FontWeight.w500,
        ),
      ),
      trailing: const Icon(Icons.arrow_forward_ios, size: 16, color: Colors.black26),
      onTap: () {
        // Add navigation or logic here
      },
    );
  }
}
