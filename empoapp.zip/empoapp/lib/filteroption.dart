import 'package:flutter/material.dart';

class FilterOption extends StatelessWidget {
  const FilterOption({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0x660D0D26),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: GestureDetector(
                onTap: () => Navigator.pop(context),
                behavior: HitTestBehavior.opaque,
                child: Container(),
              ),
            ),
            Container(
              height: MediaQuery.of(context).size.height * 0.85,
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(30),
                  topRight: Radius.circular(30),
                ),
              ),
              child: Column(
                children: [
                  _buildHeader(context),
                  Expanded(
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.symmetric(horizontal: 30),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildSearchField(),
                          const SizedBox(height: 32),
                          _buildCompanyChips(),
                          const SizedBox(height: 32),
                          _buildDivider(),
                          const SizedBox(height: 24),
                          _buildSalaryRange(),
                          const SizedBox(height: 32),
                          _buildDivider(),
                          const SizedBox(height: 24),
                          _buildFilterOption(
                            title: 'Experience Level',
                            value: 'Entry Level, Mid Level',
                          ),
                          const SizedBox(height: 24),
                          _buildDivider(),
                          const SizedBox(height: 24),
                          _buildFilterOption(
                            title: 'Location',
                            value: 'Cairo, Alexandria, Dubai',
                          ),
                          const SizedBox(height: 24),
                          _buildDivider(),
                          const SizedBox(height: 24),
                          _buildFilterOption(
                            title: 'Job Types',
                            value: '',
                          ),
                          const SizedBox(height: 16),
                          _buildJobTypeChips(),
                          const SizedBox(height: 40),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 24), // For balance
          const Text(
            'Filters',
            style: TextStyle(
              color: Color(0xFF0C0C26),
              fontSize: 20,
              fontFamily: 'Poppins',
              fontWeight: FontWeight.w600,
              height: 1.30,
              letterSpacing: -0.20,
            ),
          ),
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: const Text(
              'Done',
              style: TextStyle(
                color: Color(0xFF356899),
                fontSize: 20,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w600,
                height: 1.40,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchField() {
    return Container(
      height: 65,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          width: 1,
          color: const Color(0xFF356899),
        ),
      ),
      child: const Padding(
        padding: EdgeInsets.symmetric(horizontal: 16),
        child: Row(
          children: [
            Icon(Icons.search, color: Color(0xFF9B9BA7)),
            SizedBox(width: 12),
            Text(
              'Add a role or company or type',
              style: TextStyle(
                color: Color(0xFF9B9BA7),
                fontSize: 15,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w400,
                height: 1.50,
                letterSpacing: -0.15,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCompanyChips() {
    final companies = ['Google', 'Microsoft', 'Meta', 'Netflix', 'Amazon', 'Apple'];

    return Wrap(
      spacing: 12,
      runSpacing: 12,
      children: companies.map((company) => Chip(
        backgroundColor: const Color(0xFFD9E5F1),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(25),
        ),
        label: Text(
          company,
          style: const TextStyle(
            color: Colors.black,
            fontSize: 14,
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w500,
            height: 1.50,
            letterSpacing: -0.14,
          ),
        ),
      )).toList(),
    );
  }

  Widget _buildSalaryRange() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Salary Range',
          style: TextStyle(
            color: Color(0xFF94969D),
            fontSize: 15,
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w400,
            height: 1.50,
            letterSpacing: -0.15,
          ),
        ),
        const SizedBox(height: 16),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(
              '35\$',
              style: TextStyle(
                color: Color(0xFF0C0C26),
                fontSize: 17,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w600,
                height: 1.30,
                letterSpacing: -0.17,
              ),
            ),
            Expanded(
              child: Stack(
                children: [
                  Container(
                    height: 2,
                    margin: const EdgeInsets.symmetric(horizontal: 8),
                    decoration: BoxDecoration(
                      color: const Color(0xFFE4E4E6),
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  Container(
                    height: 2,
                    margin: const EdgeInsets.only(left: 60, right: 60),
                    decoration: BoxDecoration(
                      color: const Color(0xFF356899),
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  Positioned(
                    left: 60,
                    child: Container(
                      width: 24,
                      height: 24,
                      decoration: const ShapeDecoration(
                        color: Color(0xFF356899),
                        shape: OvalBorder(),
                      ),
                    ),
                  ),
                  Positioned(
                    right: 60,
                    child: Container(
                      width: 24,
                      height: 24,
                      decoration: const ShapeDecoration(
                        color: Color(0xFF356899),
                        shape: OvalBorder(),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const Text(
              '100\$',
              style: TextStyle(
                color: Color(0xFF0C0C26),
                fontSize: 17,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w600,
                height: 1.30,
                letterSpacing: -0.17,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildFilterOption({required String title, required String value}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          title,
          style: const TextStyle(
            color: Color(0xFF94969D),
            fontSize: 15,
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w400,
            height: 1.50,
            letterSpacing: -0.15,
          ),
        ),
        Row(
          children: [
            if (value.isNotEmpty)
              Text(
                value,
                style: const TextStyle(
                  color: Color(0xFF0C0C26),
                  fontSize: 14,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w500,
                  height: 1.50,
                  letterSpacing: -0.14,
                ),
              ),
            const SizedBox(width: 8),
            Container(
              width: 20,
              height: 20,
              decoration: const ShapeDecoration(
                color: Color(0xFFEDF2FC),
                shape: OvalBorder(),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildJobTypeChips() {
    final jobTypes = [
      {'label': 'Any', 'selected': true},
      {'label': 'Full-Time', 'selected': false},
      {'label': 'Part-Time', 'selected': false},
      {'label': 'Contract', 'selected': false},
    ];

    return Wrap(
      spacing: 12,
      runSpacing: 12,
      children: jobTypes.map((type) => Chip(
        backgroundColor: type['selected'] as bool
            ? const Color(0xFF356899)
            : const Color(0xFFD9E5F1),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(25),
        ),
        label: Text(
          type['label'] as String,
          style: TextStyle(
            color: type['selected'] as bool ? Colors.white : Colors.black,
            fontSize: 14,
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w500,
            height: 1.50,
            letterSpacing: -0.14,
          ),
        ),
      )).toList(),
    );
  }

  Widget _buildDivider() {
    return Divider(
      height: 1,
      color: const Color(0xFFE4E4E6).withAlpha(38),
    );
  }
}