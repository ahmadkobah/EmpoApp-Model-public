import 'package:flutter/material.dart';
import 'seta.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      body: Container(
        width: size.width,
        height: size.height,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment(0.50, -0.00),
            end: Alignment(0.50, 1.00),
            colors: [Color(0xFF356899), Color(0xFF1A334B)],
          ),
          borderRadius: BorderRadius.circular(0),
        ),
        child: Stack(
          children: [
            //this is bottom right circle
            // Background circles (same as splash)
            Positioned(
              left: size.width * 0.5,
              top: size.height * 0.6,
              child: Container(
                width: 100,
                height: 100,
                decoration: const ShapeDecoration(
                  color: Color(0xFFDDBDA7),
                  shape: OvalBorder(),
                ),
              ),
            ),
            //this is the bottom left rectangle
            Positioned(
              left: -size.width * 0.35,
              top: size.height * 0.6,
              child: Container(
                width: size.width * 0.8,
                height: 100,
                decoration: ShapeDecoration(
                  color: const Color(0xFFFE6D73),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(50),
                  ),
                ),
              ),
            ),

            // Logo (same as splash)
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset(
                    'assets/logobig.png',
                    width: 193,
                    height: 162,
                    fit: BoxFit.contain,
                  ),
                  const SizedBox(height: 20),

                ],
              ),
            ),

            // Top decorative elements (same as splash)
            //this is the top left circle
            Positioned(
              left: size.width * 0.3,
              top: size.height * 0.25,
              child: Container(
                width: 100,
                height: 100,
                decoration: const ShapeDecoration(
                  color: Color(0xFFFE6D73),
                  shape: OvalBorder(),
                ),
              ),
            ),
            //this is the top right rectangle
            Positioned(
              left: size.width * 0.6,
              top: size.height * 0.25,
              child: Container(
                width: size.width * 0.8,
                height: 100,
                decoration: ShapeDecoration(
                  color: const Color(0xFFDDBDA7),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(50),
                  ),
                ),
              ),
            ),

            // Replaced loading indicator with Start button
            Positioned(
              bottom: size.height * 0.1,
              left: 0,
              right: 0,
              child: Center(
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(builder: (context) => const SetA()),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                    elevation: 3,
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Text(
                        'Start',
                        style: TextStyle(
                          color: Color(0xFF356899),
                          fontSize: 16,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w500,
                          height: 1.50,
                          letterSpacing: -0.16,
                        ),
                      ),
                      SizedBox(width: 8),
                      Icon(Icons.arrow_forward, size: 16, color: Color(0xFF356899)),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}