import 'package:flutter/material.dart';
import 'register.dart';
import 'login.dart';

class loginorregister extends StatelessWidget {
  const loginorregister({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAFAFD),
      body: MediaQuery.removePadding(
        context: context,
        removeTop: true,
        child: Center(
          child: SingleChildScrollView(
            child: Container(
              width: 450,
              height: 964,
              clipBehavior: Clip.antiAlias,
              decoration: ShapeDecoration(
                color: const Color(0xFFFAFAFD),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
              child: Stack(
                children: [
                  // Background Circle
                  Positioned(
                    left: -20,
                    top: -275,
                    child: Opacity(
                      opacity: 0.20,
                      child: Container(
                        width: 450,
                        height: 450,
                        decoration: const ShapeDecoration(
                          color: Color(0xFF224261),
                          shape: OvalBorder(),
                        ),
                      ),
                    ),
                  ),

                  // Logo Text
                  const Positioned(
                    left: 130,
                    top: 100,
                    child: SizedBox(
                      width: 150,
                      child: Text(
                        'EmpÖ',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Color(0xFF356899),
                          fontSize: 32,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w600,
                          letterSpacing: -0.64,
                        ),
                      ),
                    ),
                  ),

                  // Tagline
                  const Positioned(
                    left: 65,
                    top: 250,
                    child: SizedBox(
                      width: 281,
                      height: 39,
                      child: Text(
                        'Let’s find the best job for you!',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Color(0xFF95969D),
                          fontSize: 16,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w600,
                          letterSpacing: -0.32,
                        ),
                      ),
                    ),
                  ),

                  // Login Button

                  Positioned(
                    left: 6,
                    top: 370,
                    child: GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const Login(),
                          ),
                        );
                      },
                      child: Container(
                        width: 400,
                        height: 60,
                        decoration: BoxDecoration(
                          color: const Color(0xFF356899),
                          borderRadius: BorderRadius.circular(5),
                        ),
                        child: const Center(
                          child: Text(
                            'Login',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w500,
                              letterSpacing: -0.16,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),

                  // Register Button
                  Positioned(
                    left: 6,
                    top: 470,
                    child: GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const Register(),
                          ),
                        );
                      },
                      child: Container(
                        width: 400,
                        height: 60,
                        decoration: BoxDecoration(
                          color: const Color(0xFF356899),
                          borderRadius: BorderRadius.circular(5),
                        ),
                        child: const Center(
                          child: Text(
                            'Register',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w500,
                              letterSpacing: -0.16,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),

                  // "Or continue with"
                  const Positioned(
                    left: 150,
                    top: 600,
                    child: SizedBox(
                      width: 108,
                      child: Text(
                        'Or continue with',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Color(0xFFAFB0B5),
                          fontSize: 13,
                          fontFamily: 'Circular Std',
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ),
                  ),

                  // Horizontal lines
                  const Positioned(
                    left: 10,
                    top: 600,
                    child: SizedBox(
                      width: 107,
                      child: Divider(color: Color(0xFFAFB0B5), thickness: 0.5),
                    ),
                  ),
                  const Positioned(
                    left: 302,
                    top: 600,
                    child: SizedBox(
                      width: 107,
                      child: Divider(color: Color(0xFFAFB0B5), thickness: 0.5),
                    ),
                  ),

                  // Social media icons
                  Positioned(left: 78, top: 640, child: googleIcon()),
                  Positioned(left: 178, top: 640, child: facebookIcon()),
                  Positioned(left: 278, top: 640, child: appleIcon()),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // Social media icon widgets
  Widget googleIcon() {
    return Container(
      width: 56,
      height: 56,
      decoration: const ShapeDecoration(
        color: Colors.white,
        shape: OvalBorder(),
        shadows: [
          BoxShadow(
            color: Color(0x05000000),
            blurRadius: 20,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Center(
        child: Image.asset(
          'assets/google.png',
          width: 30,
          height: 30,
          fit: BoxFit.contain,
        ),
      ),
    );
  }

  Widget facebookIcon() {
    return Container(
      width: 56,
      height: 56,
      decoration: const ShapeDecoration(
        color: Colors.white,
        shape: OvalBorder(),
        shadows: [
          BoxShadow(
            color: Color(0x05000000),
            blurRadius: 20,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Center(
        child: Image.asset(
          'assets/facebook.png',
          width: 30,
          height: 30,
          fit: BoxFit.contain,
        ),
      ),
    );
  }

  Widget appleIcon() {
    return Container(
      width: 56,
      height: 56,
      decoration: const ShapeDecoration(
        color: Colors.white,
        shape: OvalBorder(),
        shadows: [
          BoxShadow(
            color: Color(0x05000000),
            blurRadius: 20,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Center(
        child: Image.asset(
          'assets/linkedin.png',
          width: 30,
          height: 30,
          fit: BoxFit.contain,
        ),
      ),
    );
  }
}
