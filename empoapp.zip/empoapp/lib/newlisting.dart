import 'package:flutter/material.dart';
import 'homeemployer.dart';
import 'previewscreen.dart';


class NewListing extends StatefulWidget {
  const NewListing({super.key});

  @override
  State<NewListing> createState() => _NewListingState();
}

class _NewListingState extends State<NewListing> {
  final TextEditingController _salaryController = TextEditingController();
  final TextEditingController _jobTitleController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  final TextEditingController _locationController = TextEditingController();
  final TextEditingController _requirementsController = TextEditingController();
  final TextEditingController _aboutController = TextEditingController();

  String? _selectedJobType;
  final List<String> _jobTypes = [
    'Full Time',
    'Part Time',
    'Contract',
    'Internship',
    'Freelance',
    'School Training',
  ];

  String _selectedCurrency = 'USD';
  final List<String> _currencies = ['USD', 'EUR', 'GBP', 'JPY', 'CAD', 'AUD'];

  @override
  void dispose() {
    _salaryController.dispose();
    _jobTitleController.dispose();
    _descriptionController.dispose();
    _locationController.dispose();
    _requirementsController.dispose();
    _aboutController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAFAFD),
      appBar: AppBar(
        backgroundColor: const Color(0xFF3866E6),
        elevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            image: DecorationImage(
              image: AssetImage("assets/googlewallpaper.png"),
              fit: BoxFit.cover,
              colorFilter: ColorFilter.mode(
                Colors.white54,
                BlendMode.srcOver,
              ),
            ),
          ),
        ),
        title: const Text(
          'Google',
          style: TextStyle(
            color: Color(0xFF0C0C26),
            fontSize: 20,
            fontWeight: FontWeight.w600,
          ),
        ),
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFF0C0C26)),
          onPressed: () {
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => const HomeEmployer()),
                  (Route<dynamic> route) => false,
            );
          },
        ),
      ),
      body: Center(
        child: Container(
          width: 450,
          decoration: BoxDecoration(
            color: const Color(0xFFFAFAFD),
            borderRadius: BorderRadius.circular(30),
          ),
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(25),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 16),
                _buildInputBox('Job Title', _jobTitleController, icon: Icons.work),
                const SizedBox(height: 16),
                _buildInputBox('Description', _descriptionController, maxLines: 2, icon: Icons.description),
                const SizedBox(height: 16),
                _buildDropdownField('Type of the Job', _jobTypes, _selectedJobType, (val) => setState(() => _selectedJobType = val)),
                const SizedBox(height: 16),
                _buildInputBox('Location', _locationController, icon: Icons.location_on),
                const SizedBox(height: 16),
                _buildSalaryField(),
                const SizedBox(height: 16),
                _buildInputBox('Requirements', _requirementsController, maxLines: 2, icon: Icons.rule),
                const SizedBox(height: 16),
                _buildInputBox('About', _aboutController, maxLines: 2, icon: Icons.info_outline),
                const SizedBox(height: 16),

                Container(
                  child: Center(
                    child: SizedBox(
                      width: 400,
                      child: Container(
                        decoration: BoxDecoration(
                          image: DecorationImage(
                            image: AssetImage('assets/googlewallpaper.png'),
                            fit: BoxFit.cover,
                            colorFilter: ColorFilter.mode(

                              Colors.white.withAlpha(127),
                              BlendMode.srcOver,
                            ),
                          ),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: ElevatedButton(
                          onPressed: _showPreviewDialog,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.transparent,
                            shadowColor: Colors.transparent,
                            padding: const EdgeInsets.symmetric(horizontal: 48, vertical: 16),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                          child: const Text(
                            'Next',
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: 20,
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w500,
                              letterSpacing: -0.2,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 40),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildInputBox(String label, TextEditingController controller, {int maxLines = 1, IconData? icon}) {
    return TextField(
      controller: controller,
      maxLines: maxLines,
      decoration: InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(color: Color(0xFFAFB0B5), fontFamily: 'Poppins'),
        prefixIcon: icon != null ? Icon(icon, color: Color(0xFF356899)) : null,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: Color(0xFFAFB0B5)),
        ),
        focusedBorder: const OutlineInputBorder(
          borderSide: BorderSide(color: Color(0xFF356899)),
        ),
      ),
    );
  }

  Widget _buildDropdownField(String label, List<String> items, String? selectedValue, ValueChanged<String?> onChanged) {
    return DropdownButtonFormField<String>(
      value: selectedValue,
      onChanged: onChanged,
      decoration: InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(color: Color(0xFFAFB0B5), fontFamily: 'Poppins'),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: Color(0xFFAFB0B5)),
        ),
      ),
      items: items.map((type) => DropdownMenuItem(value: type, child: Text(type))).toList(),
    );
  }

  Widget _buildSalaryField() {
    return Row(
      children: [
        Expanded(
          child: TextField(
            controller: _salaryController,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
              labelText: 'Salary',
              labelStyle: const TextStyle(color: Color(0xFFAFB0B5), fontFamily: 'Poppins'),
              prefixIcon: const Icon(Icons.attach_money, color: Color(0xFF356899)),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: const BorderSide(color: Color(0xFFAFB0B5)),
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        DropdownButton<String>(
          value: _selectedCurrency,
          onChanged: (val) => setState(() => _selectedCurrency = val!),
          items: _currencies.map((currency) => DropdownMenuItem(value: currency, child: Text(currency))).toList(),
        ),
      ],
    );
  }

  void _showPreviewDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('are you sure ?'),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (_jobTitleController.text.isNotEmpty) _buildPreviewItem('Job Title', _jobTitleController.text),
              if (_descriptionController.text.isNotEmpty) _buildPreviewItem('Description', _descriptionController.text),
              if (_selectedJobType != null) _buildPreviewItem('Job Type', _selectedJobType!),
              if (_locationController.text.isNotEmpty) _buildPreviewItem('Location', _locationController.text),
              if (_salaryController.text.isNotEmpty)
                _buildPreviewItem('Salary', '${_salaryController.text} $_selectedCurrency'),
              if (_requirementsController.text.isNotEmpty)
                _buildPreviewItem('Requirements', _requirementsController.text),
              if (_aboutController.text.isNotEmpty) _buildPreviewItem('About', _aboutController.text),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('BACK TO EDIT'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => PreviewScreen()),
              );
            },
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF356899),foregroundColor: Colors.white,),
            child: const Text('SUBMIT'),
          ),
        ],
      ),
    );
  }

  Widget _buildPreviewItem(String title, String content) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          Text(content),
          const Divider(),
        ],
      ),
    );
  }
}
